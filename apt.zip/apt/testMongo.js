var MongoClient = require('mongodb').MongoClient;

var uri = "mongodb+srv://apartmen:apartment@shekharatole-3kot9.mongodb.net/test?retryWrites=true";
MongoClient.connect(uri, { useNewUrlParser: true }, function(err,db){
    console.log('Connected...');

    // Create a collection we want to drop later
  //var collection = db.collection('apartment');

  // Insert a bunch of documents for the testing
  //collection.insertMany([{a:1}, {a:2}, {a:3}], {w:1}, function(err, result) {

  //});

    //const collection = db.db("db_apartment").collection("apartment");
    //const cursor = db.collection('apartment').find({});
    //console.log(cursor);
});