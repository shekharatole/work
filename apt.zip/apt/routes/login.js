exports.login=function(req, res){
    if(req.method == "POST"){
        var post  = req.body;
        var name= post.username;
        var password= post.password;
        var sess = req.session;

        var selectSql = "SELECT SL.email_id, SL.id, SL.name FROM site_login AS SL JOIN user_role AS UR ON SL.id=UR.user_id JOIN site_role AS SR ON SR.role_id=UR.role_id WHERE SL.email_id= '"+name+"' AND SL.password='"+password+"' AND SR.role_name='Superadministrator'";
        db.query(selectSql, function(err, results){ 
            if(results.length){
                sess.superAdminId = results[0].id;
                sess.user = results[0];
                console.log(results[0].email_id);
                res.redirect('/superadmin/dashboard');
            }else{
                message = 'Wrong Credentials.';
                res.render('superadmin/login.ejs',{invalidCredentialsMessage: message});
            }
        });
    }
}

exports.logout = function(req,res){
    req.session.destroy();
    res.redirect('/superadmin/login');
}