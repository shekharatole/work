exports.superadmin = function(req, res){
    //console.log(req.session);
    if(req.session.superAdminId == '1'){    
        res.redirect('/superadmin/dashboard');
    }else{
        res.redirect('/superadmin/login');
    }    
}

exports.login = function(req, res){
    var message = '';
    if(req.session.superAdminId == '1'){    
        res.redirect('/superadmin/dashboard');
    }else{
        res.render('superadmin/login',{invalidCredentialsMessage:message});
    }    
}

exports.loginsecure = function(req, res){
    var message = 'Wrong Credentials';
    res.render('superadmin/login',{invalidCredentialsMessage:message});
}

exports.dashboard = function(req,res){    
    if(req.session.superAdminId == '1'){    
        res.render('superadmin/index');
    }else{
        res.redirect('/superadmin/login');
    }  
}