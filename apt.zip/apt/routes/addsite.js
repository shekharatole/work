exports.addsite = function(req,res){
    if(req.session.superAdminId == '1'){    
        res.render('superadmin/add-site');
    }else{
        res.redirect('/superadmin/login');
    }
}

exports.insertdata = function(req,res){
    if(req.session.superAdminId == '1'){    
        res.render('superadmin/add-site');
    }else{
        res.redirect('/superadmin/login');
    }
}
