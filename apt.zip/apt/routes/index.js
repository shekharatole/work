exports.index = function(req, res){    
    if(req.session.superAdminId == '1'){    
        //res.render('index');
        res.redirect('/superadmin/dashboard');
    }else{
        res.redirect('/superadmin/login');
    }
    //res.render('index.ejs');
   /* var user =  req.session.user,
    userId = req.session.userId;

    if(userId == null || userId == ''){
        var message = '';
        res.render('index',{message: message});
    }
    else{
        res.render('profile.ejs', {user:user});
    }*/
}