var express = require('express'), 
    routes = require('./routes'),
    superadmin = require('./routes/superadmin'),
    login = require('./routes/login'),
    addsite = require('./routes/addsite'),
    http = require('http'),
    path = require('path'),
    bodyParser=require("body-parser"),
    mysql      = require('mysql');

//Express object
var app = express();

//Set the view engine
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

//Set the static path
app.use(express.static(path.join(__dirname, 'public')));

//Session setting
var session = require('express-session');
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}))

//Use of body parser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Database connection
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'project'
  });
connection.connect();
global.db = connection;

//Get request from url
app.get('/', routes.index);//call for main index page
app.get('/index', routes.index);
app.get('/superadmin', superadmin.superadmin);
app.get('/superadmin/login', superadmin.login);
app.get('/loginsecure',superadmin.loginsecure);//for get
app.get('/superadmin/dashboard', superadmin.dashboard);
app.get('/superadmin/add-site',addsite.addsite);
app.get('/logout',login.logout);

//Post request from url
app.post('/loginsecure', login.login);//call for login post
app.post('/insertdata', addsite.insertdata);

//Start app
app.listen(8080, function(){
    console.log("server start at port 8080");
});
