<?php 
	include('header.php');
?>
    <!-- Content -->
    <div class="page-content">
        <!-- Slider -->
        <div class="main-slider style-two default-banner">
            <div class="tp-banner-container">
                <div class="tp-banner" >
                    <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                        <!-- START REVOLUTION SLIDER 5.3.0.2 -->
                        <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.3.0.2">
                            <ul>
                                <!-- SLIDE 1 -->
                                <li data-index="rs-1000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/slide1.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                id="slide-100-layer-1" 
                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                data-width="full"
                data-height="full"
                data-whitespace="nowrap"
                data-type="shape" 
                data-basealign="slide" 
                data-responsive_offset="off" 
                data-responsive="off"
                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
				<div class="tp-caption  tp-resizeme" 
				id="slide-100-layer-2" 
				data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>
                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption tp-resizeme" 
                id="slide-100-layer-3" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']" 
                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
           
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"

                style="z-index: 13; 
                font-weight: 500; 
                color: rgba(255, 255, 255, 0.85);
                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                id="slide-100-layer-4"						
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']" 
                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
                
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[ 
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 13;"><a href="javascript:void(0);" class="site-button  button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                                <!-- SLIDE 2 -->
                                <li data-index="rs-2000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/slide2.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                id="slide-200-layer-1" 
                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                data-width="full"
                data-height="full"
                data-whitespace="nowrap"
                data-type="shape" 
                data-basealign="slide" 
                data-responsive_offset="off" 
                data-responsive="off"
                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption  tp-resizeme" 
                id="slide-200-layer-2" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>

                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption tp-resizeme" 
                id="slide-200-layer-3" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']" 
                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
           
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"

                style="z-index: 13; 
                font-weight: 500; 
                color: rgba(255, 255, 255, 0.85);
                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                id="slide-200-layer-4"						
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']" 
                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
                
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[ 
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 13;"><a href="javascript:void(0);" class="site-button  button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                                <!-- SLIDE 3 -->
                                <li data-index="rs-3000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slide3.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                                id="slide-300-layer-1" 
                                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                data-width="full"
                                data-height="full"
                                data-whitespace="nowrap"
                                data-type="shape" 
                                data-basealign="slide" 
                                data-responsive_offset="off" 
                                data-responsive="off"
                                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                
                                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                id="slide-300-layer-2" 
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>

                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption  tp-resizeme" 
                                id="slide-300-layer-3" 
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']"  
                                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                                data-whitespace="['normal','normal','normal','normal']"
                     
                                data-type="text" 
                                data-responsive_offset="on"
                                data-frames='[
                                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                ]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 13; 
                                font-weight: 500; 
                                color: rgba(255, 255, 255, 0.85);
                                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the  when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                id="slide-300-layer-4"						
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']"  
                                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                                data-whitespace="['normal','normal','normal','normal']"
                                
                                data-type="text" 
                                data-responsive_offset="on"
                                data-frames='[ 
                                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                ]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                
                                style="z-index: 13;"><a href="javascript:void(0);" class="site-button   button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                            </ul>
                            <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                        </div>
                    </div>
                    <!-- END REVOLUTION SLIDER -->
                </div>
            </div>
        </div>
        <!-- Slider END -->
        <!-- meet & ask -->
        <div class="section-full z-index100 meet-ask-outer">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 meet-ask-row p-tb30">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="icon-bx-wraper clearfix text-white left">
                                    <div class="icon-xl "> <span class=" icon-cell"><i class="fa fa-building-o"></i></span> </div>
                                    <div class="icon-content">
                                        <h3 class="dlab-tilte text-uppercase m-b10">Meet & Ask</h3>
                                        <p>Lorem Ipsum is simply dummy text the printing and industry dummy Ipsum [...] </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 m-t20"> <a href="#" class="site-button-secondry button-skew m-l10"><span>Contact Us</span><i class="fa fa-angle-right"></i></a> <a href="#" class="site-button-secondry button-skew m-l20"><span>View more</span><i class="fa fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- meet & ask END -->
        <!-- About Company -->
        <div class="section-full  bg-gray content-inner-1" style="background-image: url(images/bg-img.png); background-repeat: repeat-x; background-position: left bottom -37px;">
            <div class="container">
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-7">
                            <h2 class="text-uppercase"> About  Company</h2>
                            <div class="dlab-separator-outer ">
                                <div class="dlab-separator bg-secondry style-skew"></div>
                            </div>
                            <div class="clear"></div>
                            <p><strong>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</strong></p>
                            <p class="m-b50">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the with the release of Letraset sheets containing Lorem Ipsum [...]</p>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-cogs text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE EXPERTS</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-users text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE FRIENDLY</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-car text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE ACCURATE</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-trophy text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE TRUSTED</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="dlab-thu m"><img src="images/worker.png" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Company END -->
        <!-- Our Projects  -->
        <div class="section-full bg-img-fix content-inner overlay-black-middle" style="background-image:url(images/background/bg1.jpg);">
            <div class="container">
                <div class="section-head  text-center text-white">
                    <h2 class="text-uppercase">Our Projects</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-white style-skew"></div>
                    </div>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the been when an unknown printer.</p>
                </div>
                <div class="site-filters clearfix center  m-b40">
                    <ul class="filters" data-toggle="buttons">
                        <li data-filter="" class="btn active">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew active"><span>Show All</span></a> </li>
                        <li data-filter="home" class="btn">
                            <input type="radio" >
                            <a href="#" class="site-button-secondry button-skew"><span>Brakes</span></a> </li>
                        <li data-filter="office" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Suspension</span></a> </li>
                        <li data-filter="commercial" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Wheels</span></a> </li>
                        <li data-filter="window" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Steering	</span></a> </li>
                    </ul>
                </div>
                <div class="row">
                    <ul id="masonry" class="dlab-gallery-listing gallery-grid-4 gallery mfp-gallery m-b0">
                        <li data-filter="home" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic1.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic1.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="office" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow dlab-img-effect zoom"> <a href="javascript:void(0);"> <img src="images/our-work/pic2.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic2.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="children-aid" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic3.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a href="images/our-work/pic3.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="commercial" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic4.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic4.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="window" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic5.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic5.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="apartment" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic6.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic6.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Our Projects END -->
        <!-- OUR SERVICES -->
        <div class="section-full  bg-white content-inner overlay-white-middle" style="background-image:url(images/background/bg5.png); background-position:right center; background-repeat:no-repeat; background-size: auto 100%;">
            <div class="container">
                <div class="section-head text-center">
                    <h2 class="text-uppercase"> OUR SERVICES</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-secondry style-skew"></div>
                    </div>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the been when an unknown printer.</p>
                </div>
                <div class="section-content">
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-life-saver text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">AIR CONDITIONING</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-car text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">BRAKE REPAIR</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-thumbs-up text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">LUBE, OIL AND FILTERS</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-trophy text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">BELTS AND HOSES</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-cubes text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">ENGINE DIAGNOSTICS</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b10">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-area-chart text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">TIRE AND WHEEL SERVICES</h5>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- OUR SERVICES END-->
        <!-- Company staus -->
        <div class="section-full text-white bg-img-fix content-inner overlay-black-middle" style="background-image:url(images/background/bg4.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-building-o m-r20"></i> <span class="counter">1035</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Active Experts</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-group m-r20"></i> <span class="counter">1226</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Happy Client</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-slideshare m-r20"></i> <span class="counter">1552</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Workers Hand</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b10">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-home m-r20"></i> <span class="counter">1156</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Completed Project</span></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Company staus END -->
        <!-- Team member -->
        <div class="section-full bg-white content-inner">
            <div class="container">
                <div class="section-head text-center ">
                    <h2 class="text-uppercase"> Meet The Team</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-secondry style-skew"></div>
                    </div>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the been when an unknown printer.</p>
                </div>
                <div class="section-content text-center ">
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="dlab-box m-b30">
                                <div class="dlab-media"> <a href="javascript:;"> <img width="358" height="460" alt="" src="images/our-team/pic1.jpg"> </a>
                                    <div class="dlab-info-has skew-has  bg-primary">
                                        <ul class="dlab-social-icon border">
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-twitter" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-linkedin" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="p-a10">
                                    <h4 class="dlab-title text-uppercase"><a href="javascript:;">Nashid Martines</a></h4>
                                    <span class="dlab-member-position">Director</span> </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="dlab-box m-b30">
                                <div class="dlab-media"> <a href="javascript:;"> <img width="358" height="460" alt="" src="images/our-team/pic2.jpg"> </a>
                                    <div class="dlab-info-has skew-has bg-primary">
                                        <ul class="dlab-social-icon border">
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-twitter" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-linkedin" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="p-a10 bg-white">
                                    <h4 class="dlab-title text-uppercase"><a href="javascript:;">konne Backfield</a></h4>
                                    <span class="dlab-member-position">Designer</span> </div>
                            </div>
                        </div>
						<div class="col-md-3 col-sm-6">
                            <div class="dlab-box m-b30">
                                <div class="dlab-media"> <a href="javascript:;"> <img width="358" height="460" alt="" src="images/our-team/pic3.jpg"> </a>
                                    <div class="dlab-info-has skew-has bg-primary">
                                        <ul class="dlab-social-icon border">
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-twitter" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-linkedin" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="p-a10">
                                    <h4 class="dlab-title text-uppercase"><a href="javascript:;">Hackson Willingham</a></h4>
                                    <span class="dlab-member-position">Developer</span> </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="dlab-box m-b10">
                                <div class="dlab-media"> <a href="javascript:;"> <img width="358" height="460" alt="" src="images/our-team/pic4.jpg"> </a>
                                    <div class="dlab-info-has skew-has bg-primary">
                                        <ul class="dlab-social-icon border">
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-twitter" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-linkedin" href="javascript:void(0);"></a></li>
                                            <li><a class="fa fa-facebook" href="javascript:void(0);"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="p-a10">
                                    <h4 class="dlab-title text-uppercase"><a href="javascript:;">konne Backfield</a></h4>
                                    <span class="dlab-member-position">Manager</span> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team member END -->
        <!-- Latest blog -->
        <div class="section-full content-inner ">
            <div class="container">
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Latest blog post</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-secondry style-skew"></div>
                    </div>
                </div>
                <div class="section-content ">
                    <div class="row equal-wraper">
                        <div class="col-md-4 col-sm-4 equal-col m-b10">
                            <div class="blog-post latest-blog-1 date-style-3 skew-date">
                                <div class="dlab-post-media dlab-img-effect zoom-slow"> <a href="javascript:;"><img src="images/blog/latest-blog/pic1.jpg" alt=""></a> </div>
                                <div class="dlab-post-info p-t20">
                                    <div class="dlab-post-title ">
                                        <h3 class="post-title"><a href="javascript:;">Title of first blog post</a></h3>
                                    </div>
                                    <div class="dlab-post-meta ">
                                        <ul>
                                            <li class="post-date"> <i class="fa fa-calendar"></i><strong>10 Aug</strong> <span> 2016</span> </li>
                                            <li class="post-author"><i class="fa fa-user"></i>By <a href="javascript:;">demongo</a> </li>
                                            <li class="post-comment"><i class="fa fa-comments"></i> <a href="javascript:;">0 comment</a> </li>
                                        </ul>
                                    </div>
                                    <div class="dlab-post-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 equal-col m-b10">
                            <div class="blog-post latest-blog-1 date-style-3 skew-date">
                                <div class="dlab-post-media dlab-img-effect zoom-slow"> <a href="javascript:;"><img src="images/blog/latest-blog/pic2.jpg" alt=""></a> </div>
                                <div class="dlab-post-info p-t20">
                                    <div class="dlab-post-title ">
                                        <h3 class="post-title"><a href="javascript:;">Title of first blog post</a></h3>
                                    </div>
                                    <div class="dlab-post-meta ">
                                        <ul>
                                            <li class="post-date"> <i class="fa fa-calendar"></i><strong>10 Aug</strong> <span> 2016</span> </li>
                                            <li class="post-author"><i class="fa fa-user"></i>By <a href="javascript:;">demongo</a> </li>
                                            <li class="post-comment"><i class="fa fa-comments"></i> <a href="javascript:;">0 comment</a> </li>
                                        </ul>
                                    </div>
                                    <div class="dlab-post-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 equal-col m-b10">
                            <div class="blog-post latest-blog-1 date-style-3 skew-date">
                                <div class="dlab-post-media dlab-img-effect zoom-slow"> <a href="javascript:;"><img src="images/blog/latest-blog/pic3.jpg" alt=""></a> </div>
                                <div class="dlab-post-info p-t20">
                                    <div class="dlab-post-title ">
                                        <h3 class="post-title"><a href="javascript:;">Title of first blog post</a></h3>
                                    </div>
                                    <div class="dlab-post-meta ">
                                        <ul>
                                            <li class="post-date"> <i class="fa fa-calendar"></i><strong>10 Aug</strong> <span> 2016</span> </li>
                                            <li class="post-author"><i class="fa fa-user"></i>By <a href="javascript:;">demongo</a> </li>
                                            <li class="post-comment"><i class="fa fa-comments"></i> <a href="javascript:;">0 comment</a> </li>
                                        </ul>
                                    </div>
                                    <div class="dlab-post-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Latest blog END -->
        <!-- Testimonials blog -->
        <div class="section-full overlay-black-middle bg-img-fix content-inner-1" style="background-image:url(images/background/bg2.jpg);">
            <div class="container">
                <div class="section-head text-white text-center">
                    <h2 class="text-uppercase">What peolpe are saying</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-white  style-skew"></div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="testimonial-four">
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the standard dummy text ever since the when printer. [...]</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonials blog END -->
        <!-- Client logo -->
        <div class="section-full dlab-we-find bg-img-fix p-t50 p-b50 ">
            <div class="container">
                <div class="section-content">
                    <div class="client-logo-carousel mfp-gallery gallery owl-btn-center-lr">
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><a href="#"><img src="images/client-logo/logo1.jpg" alt=""></a></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"> <a href="#"><img src="images/client-logo/logo2.jpg" alt=""></a> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"> <a href="#"><img src="images/client-logo/logo1.jpg" alt=""></a> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"> <a href="#"><img src="images/client-logo/logo3.jpg" alt=""></a> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"> <a href="#"><img src="images/client-logo/logo4.jpg" alt=""></a> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"> <a href="#"><img src="images/client-logo/logo3.jpg" alt=""></a> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Client logo END -->
    </div>
    <!-- Content END-->
    
<?php 
	include('footer.php');
?>