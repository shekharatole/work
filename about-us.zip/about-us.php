<?php
	include('header.php');
?>
    <!-- Content -->
    <div class="page-content">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle" style="background-image:url(images/background/bg4.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry">
                    <h1 class="text-white">About us 1</h1>
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="index.php">Home</a></li>
                    <li>About us</li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb row END -->
        <!-- contact area -->
        <div class="content">
            <!-- About Company -->
            <div class="section-full bg-gray content-inner" style="background-image: url(images/bg-img.png); background-repeat: repeat-x; background-position: left bottom -37px;">
                <div class="container">
                    <div class="section-content">
                        <div class="row">
                        <div class="col-md-7">
                            <h2 class="text-uppercase"> About  Company</h2>
                            <div class="dlab-separator-outer ">
                                <div class="dlab-separator bg-secondry style-skew"></div>
                            </div>
                            <div class="clear"></div>
                            <p><strong>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</strong></p>
                            <p class="m-b50">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the with the release of Letraset sheets containing Lorem Ipsum [...]</p>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-cogs text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE EXPERTS</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-users text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE FRIENDLY</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-car text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE ACCURATE</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm bg-secondry "> <span class="icon-cell"><i class="fa fa-trophy text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h3 class="dlab-tilte text-uppercase">WE'RE TRUSTED</h3>
                                            <p>Lorem ipsum dolor sit adipiscing sed diam nonummy end [...]</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="dlab-thu m"><img src="images/worker.png" alt=""></div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <!-- About Company END -->
            <!-- Counter -->
            <div class="section-full bg-gray bg-img-fix content-inner overlay-black-middle" style="background-image:url(images/background/bg12.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="m-b30 text-white text-center">
                                <div class="icon-bx-lg radius  border-2 m-b20">
                                    <div class="icon-cell text-white"> <i class="fa fa-building-o"></i> </div>
                                </div>
                                <div class="counter font-26 font-weight-800 text-primary m-b5">1035</div>
                                <div class="aon-separator bg-primary"></div>
                                <p>Completed Project</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="m-b30 text-white text-center">
                                <div class="icon-bx-lg radius  border-2 m-b20">
                                    <div class="icon-cell text-white"> <i class="fa fa-male"></i> </div>
                                </div>
                                <div class="counter font-26 font-weight-800 text-primary m-b5">1124</div>
                                <div class="aon-separator bg-primary"></div>
                                <p>Active Experts</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class=" m-b30 text-white text-center">
                                <div class="icon-bx-lg radius  border-2 m-b20">
                                    <div class="icon-cell text-white"> <i class="fa fa-male"></i> </div>
                                </div>
                                <div class="counter font-26 font-weight-800 text-primary m-b5">834</div>
                                <div class="aon-separator bg-primary"></div>
                                <p>Happy Clients</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="m-b10 text-white text-center">
                                <div class="icon-bx-lg radius  border-2 m-b20">
                                    <div class="icon-cell text-white"> <i class="fa fa-area-chart"></i> </div>
                                </div>
                                <div class="counter font-26 font-weight-800 text-primary m-b5">538</div>
                                <div class="aon-separator bg-primary"></div>
                                <p>Developer Hand</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Counter End -->
            <!-- Architecture -->
            <div class="section-full text-center aon-our-team bg-white content-inner-1">
                <div class="container">
                    <div class="section-head">
                        <h2 class="text-uppercase"> OUR SERVICES</h2>
                        <span class="title-small">Best Car Services</span>
                        <div class="after-titile-line"></div>
                    </div>
                    <div class="section-content">
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-life-saver"></i></a> </div>
                                    <div class="icon-content">
                                        <h5 class="dlab-tilte text-uppercase">AIR CONDITIONING</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-car"></i></a> </div>
                                    <div class="icon-content">
                                        <h5 class="dlab-tilte text-uppercase">BRAKE REPAIR</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-thumbs-up"></i></a> </div>
                                    <div class="icon-content">
                                        <h5 class="dlab-tilte text-uppercase">LUBE, OIL AND FILTERS</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row p-t50">
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-trophy"></i></a> </div>
                                    <div class="icon-content">
                                       <h5 class="dlab-tilte text-uppercase">BELTS AND HOSES</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-cubes"></i></a> </div>
                                    <div class="icon-content">
                                        <h5 class="dlab-tilte text-uppercase">ENGINE DIAGNOSTICS</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="icon-bx-wraper center">
                                    <div class="icon-bx-sm radius bg-primary m-b20"> <a href="#" class="icon-cell"><i class="fa fa-area-chart"></i></a> </div>
                                    <div class="icon-content">
                                         <h5 class="dlab-tilte text-uppercase">TIRE AND WHEEL SERVICES</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod [...]</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Architecture End -->
            <!-- What peolpe are saying -->
            <div class="section-full overlay-black-middle bg-img-fix content-inner-1" style="background-image:url(images/background/bg6.jpg);">
                <div class="container">
                    <div class="section-head text-center text-white">
                        <h2 class="text-uppercase">What peolpe are saying</h2>
                        <span class="title-small">Best Cleaning Deals</span>
                        <div class="after-titile-line"></div>
                    </div>
                    <div class="section-content">
                        <div class="testimonial-one">
                            <div class="item">
                                <div class="testimonial-1 testimonial-bg">
                                    <div class="testimonial-pic quote-left radius shadow"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                    <div class="testimonial-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets conta</p>
                                    </div>
                                    <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-1 testimonial-bg">
                                    <div class="testimonial-pic quote-left radius shadow"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                    <div class="testimonial-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets conta</p>
                                    </div>
                                    <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-1 testimonial-bg">
                                    <div class="testimonial-pic quote-left radius shadow"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                    <div class="testimonial-text">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets conta</p>
                                    </div>
                                    <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- What peolpe are saying END -->
        </div>
        <!-- contact area END -->
    </div>
    <!-- Content END-->
<?php
	include('footer.php');
?>