
		<!-- Footer -->
		<footer class="site-footer">
		  <!-- newsletter part -->
		  <div class="p-a 30 bg-primary dlab-newsletter">
		    <div class="container equal-wraper">
		      <div class="row">
		        <form action="# ">
		          <div class="col-md-4 col-sm-4">
		            <div class="icon-bx-wraper equal-col p-t30 p-b20 left">
		              <div class="icon-lg text-primary radius">
		                <a href="#" class="icon-cell">
		                  <i class="fa fa-envelope-o">
		                  </i>
		                </a>
		              </div>
		              <div class="icon-content">
		                <strong class="text-black text-uppercase font-18">
		                  Subscribe
		                </strong>
		                <h2 class="dlab-tilte text-uppercase">
		                  Our Newsletter
		                </h2>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-4 col-sm-4">
		            <div class="input-group equal-col p-t40  p-b20">
		              <input name="name" required placeholder="Email address " class="form-control" type="text">
		            </div>
		          </div>
		          <div class="col-md-3 col-sm-3 col-sm-offset-1">
		            <div class="input-group equal-col  p-t40 p-b20 skew-subscribe">
		              <button type="button" value="submit" name="submit" class="site-button-secondry button-skew z-index1">
		                <span>
		                  Subscribe
		                </span>
		                <i class="fa fa-angle-right">
		                </i>
		              </button>
		            </div>
		          </div>
		        </form>
		      </div>
		    </div>
		  </div>
		  <!-- footer top part -->
		  <div class="footer-top">
		    <div class="container">
		      <div class="row">
		        <div class="col-md-3 col-sm-6 footer-col-4">
		          <div class="widget widget_about">
		            <div class="logo-footer">
		              <img src="images/logo-dark.png" alt="">
		            </div>
		            <p>
		              <strong>
		                City Car Cares
		              </strong>ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore agna aliquam erat . wisi enim ad minim veniam, quis tation. sit amet, consec tetuer.ipsum dolor sit amet, consectetuer adipiscing.ipsum dolor sit amet, consectetuer adipiscing elitam nonummy nibh euis[...]
		            </p>
		            <ul class="dlab-social-icon border">
		              <li>
		                <a class="fa fa-facebook" href="javascript:void(0);">
		                </a>
		              </li>
		              <li>
		                <a class="fa fa-twitter" href="javascript:void(0);">
		                </a>
		              </li>
		              <li>
		                <a class="fa fa-linkedin" href="javascript:void(0);">
		                </a>
		              </li>
		              <li>
		                <a class="fa fa-facebook" href="javascript:void(0);">
		                </a>
		              </li>
		            </ul>
		          </div>
		        </div>
		        <div class="col-md-3 col-sm-6 footer-col-4">
		          <div class="widget recent-posts-entry">
		            <h4 class="m-b15 text-uppercase">
		              Total Visitors Count :
		              <?php
		              $handle = fopen("counter.txt", "r");
		              if(!$handle)
		              {
		                echo "Could not open the file" ;
		              }
		              else
		              {
		                $counter = ( int ) fread ($handle,20) ;
		                fclose ($handle) ;
		                $counter++ ;
		                echo$counter;
		                $handle = fopen("counter.txt", "w" ) ;
		                fwrite($handle,$counter) ;
		                fclose ($handle) ;
		              }
		              ?>
		            </h4>
		          </div>
		        </div>
		        <div class="col-md-3 col-sm-6 footer-col-4">
		          <div class="widget widget_services">
		            <h4 class="m-b15 text-uppercase">
		              Our services
		            </h4>
		            <div class="dlab-separator-outer m-b10">
		              <div class="dlab-separator bg-white style-skew">
		              </div>
		            </div>
		            <ul>
		              <li>
		                <a href="engine-diagnostics.php">
		                  Engine Diagnostics
		                </a>
		              </li>
		              <li>
		                <a href="lube-oil-and-filters.php">
		                  Lube, Oil and Filters
		                </a>
		              </li>
		              <li>
		                <a href="belts-and-hoses.php">
		                  Belts and Hoses
		                </a>
		              </li>
		              <li>
		                <a href="air-conditioning.php">
		                  Air Conditioning
		                </a>
		              </li>
		              <li>
		                <a href="brake-repair.php">
		                  Brake Repair
		                </a>
		              </li>
		              <li>
		                <a href="tire-and-wheel-services.php">
		                  Tire And Wheel Services
		                </a>
		              </li>
		            </ul>
		          </div>
		        </div>
		        <div class="col-md-3 col-sm-6 footer-col-4">
		          <div class="widget widget_getintuch">
		            <h4 class="m-b15 text-uppercase">
		              Contact us
		            </h4>
		            <div class="dlab-separator-outer m-b10">
		              <div class="dlab-separator bg-white style-skew">
		              </div>
		            </div>
		            <ul>
		              <li>
		                <i class="fa fa-map-marker">
		                </i>
		                <strong>
		                  address
		                </strong>demo address #8901 Marmora Road Chi Minh City, Vietnam
		              </li>
		              <li>
		                <i class="fa fa-phone">
		                </i>
		                <strong>
		                  phone
		                </strong>0800-123456 (24/7 Support Line)
		              </li>
		              <li>
		                <i class="fa fa-fax">
		                </i>
		                <strong>
		                  FAX
		                </strong>(123) 123-4567
		              </li>
		              <li>
		                <i class="fa fa-envelope">
		                </i>
		                <strong>
		                  email
		                </strong>info@demo.com
		              </li>
		            </ul>
		          </div>
		        </div>
		      </div>
		    </div>
		  </div>
		  <!-- footer bottom part -->
		  <div class="footer-bottom footer-line">
		    <div class="container">
		      <div class="row">
		        <div class="col-md-4 text-left">
		          <span>
		            &copy; Copyright <?php echo  date("Y");;?>
		          </span>
		        </div>
		        <div class="col-md-4 text-center">
		          <span>
		            Design By & Maintain By
		            <i class="fa fa-heart text-primary heart">
		            </i> Shekhar Atole - 9975170828
		          </span>
		        </div>
		        <div class="col-md-4 text-right ">
		          <a href="about-us.php">
		            About Us
		          </a>
		          <a href="why-us.php">
		            Why Us
		          </a>
		          <a href="contact-us.php">
		            Contact Us
		          </a>
		        </div>
		      </div>
		    </div>
		  </div>
		</footer>    <!-- Footer END-->
		<!-- scroll top button -->
		<button class="scroltop fa fa-arrow-up style5" >
		</button>
		</div>

		<!-- JavaScript  files ========================================= -->
		<script src="js/combine.js">
		</script>
		<script  src="plugins/revolution/js/jquery.themepunch.tools.min.js">
		</script>
		<script  src="plugins/revolution/js/jquery.themepunch.revolution.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.actions.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.migration.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js">
		</script>
		<script  src="plugins/revolution/js/extensions/revolution.extension.video.min.js">
		</script>
		<script  src="js/rev.slider.js">
		</script>
		<script >
		  jQuery(document).ready(function()
		    {
		      'use strict';
		      dz_rev_slider_2();
		    });  /*ready*/
		</script>
	</body>
</html>
