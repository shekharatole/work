<?php
	include('header.php');
?>
    <!-- Content -->
    <div class="page-content">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle" style="background-image:url(images/main-slider/slide2.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry">
                    <h1 class="text-white">Engine Diagnostics</h1>
					<div class="dlab-separator bg-primary"></div>
					<p class="text-white max-w800">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley</p>
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="#">Home</a></li>
                    <li>Engine Diagnostics</li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb row END -->
        <!-- contact area -->
        <div class="section-full bg-white content-inner">
            <!-- About Company -->
            <div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-4">
						<div class="widget_services style-2 m-b40">
							<ul>
								<li><a href="all-service.html">ALL SERVICES</a> </li>
								<li class="active"><a href="engine-diagnostics.html">ENGINE DIAGNOSTICS</a>  </li>
								<li><a href="lube-oil-and-filters.html">LUBE OIL AND FILTERS</a>  </li>
								<li><a href="belts-and-hoses.html">BELTS AND HOSES</a>  </li>
								<li><a href="air-conditioning.html">AIR CONDITIONING</a> </li>
								<li><a href="brake-repair.html">BRAKE REPAIR</a> </li>
								<li><a href="tire-and-wheel-services.html">TIRE AND WHEEL SERVICES</a> </li>
							</ul>
						</div>
						<div class="widget">
							<h4 class="widget-title">Get your brochures</h4>
							<div class="download-file">
								<ul>
									<li>
										<a href="files/pdf-sample.pdf" target="_blank">
											<span><i class="fa fa-file-pdf-o"></i></span>
											<p>Company Brochures</p>
											<i class="fa fa-download"></i>
										</a>
									</li>
									<li>
										<a href="files/pdf-sample.pdf" target="_blank">
											<span><i class="fa fa-file-pdf-o"></i></span>
											<p>Company Info</p>
											<i class="fa fa-download"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="widget  widget_getintuch">
							<h4 class="widget-title">Contact us</h4>
							<ul>
								<li><i class="fa fa-map-marker"></i><strong>address</strong> demo address #8901 Marmora Road Chi Minh City, Vietnam </li>
								<li><i class="fa fa-phone"></i><strong>phone</strong>0800-123456 (24/7 Support Line)<br>
									+ (20) 1234 0078 (Fax)</li>
								<li><i class="fa fa-envelope"></i><strong>email</strong>info@demo.com</li>
							</ul>
						</div>
					</div>
					<div class="col-md-9 col-sm-8">
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="dlab-box">
									<div class="dlab-media"> <a href="#"><img src="images/our-services/img1.jpg" alt=""></a> </div>
									<div class="dlab-info m-t30 ">
										<h4 class="dlab-title m-t0"><a href="#">The Initial Planning </a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley. </p>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since. </p>
									</div>
									
								</div>
								
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="dlab-box">
									<div class="dlab-media m-b30 p-b5"> <a href="#"><img src="images/our-services/img2.jpg" alt=""></a></div>
									<div class="dlab-media"> <a href="#"><img src="images/our-services/img3.jpg" alt=""></a></div>
									<div class="dlab-info m-t30">
										<h4 class="dlab-title m-t0"><a href="#">From Start To finish</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley. </p>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since. </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				</div>
				<!-- About Company END -->
			</div>
        <!-- contact area  END -->
		</div>
    <!-- Content END-->
<?php
	include('footer.php');
?>