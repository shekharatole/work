<?php 
	include('header.php');
?>
    <!-- Content -->
    <div class="page-content">
        <!-- Slider -->
        <div class="main-slider style-two default-banner">
            <div class="tp-banner-container">
                <div class="tp-banner" >
                    <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                        <!-- START REVOLUTION SLIDER 5.3.0.2 -->
                        <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.3.0.2">
                            <ul>
                                <!-- SLIDE 1 -->
                                <li data-index="rs-1000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/slide1.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide1.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                id="slide-100-layer-1" 
                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                data-width="full"
                data-height="full"
                data-whitespace="nowrap"
                data-type="shape" 
                data-basealign="slide" 
                data-responsive_offset="off" 
                data-responsive="off"
                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
				<div class="tp-caption  tp-resizeme" 
				id="slide-100-layer-2" 
				data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>
                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption tp-resizeme" 
                id="slide-100-layer-3" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']" 
                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
           
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"

                style="z-index: 13; 
                font-weight: 500; 
                color: rgba(255, 255, 255, 0.85);
                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                id="slide-100-layer-4"						
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']" 
                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
                
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[ 
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 13;"><a href="javascript:void(0);" class="site-button  button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                                <!-- SLIDE 2 -->
                                <li data-index="rs-2000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/slide2.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                id="slide-200-layer-1" 
                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                data-width="full"
                data-height="full"
                data-whitespace="nowrap"
                data-type="shape" 
                data-basealign="slide" 
                data-responsive_offset="off" 
                data-responsive="off"
                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption  tp-resizeme" 
                id="slide-200-layer-2" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>

                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption tp-resizeme" 
                id="slide-200-layer-3" 
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']" 
                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
           
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"

                style="z-index: 13; 
                font-weight: 500; 
                color: rgba(255, 255, 255, 0.85);
                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                id="slide-200-layer-4"						
                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']" 
                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                data-whitespace="['normal','normal','normal','normal']"
                
                data-type="text" 
                data-responsive_offset="on"
                data-frames='[ 
                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                ]'
                data-textAlign="['left','left','left','left']"
                data-paddingtop="[0,0,0,0]"
                data-paddingright="[0,0,0,0]"
                data-paddingbottom="[0,0,0,0]"
                data-paddingleft="[0,0,0,0]"
                
                style="z-index: 13;"><a href="javascript:void(0);" class="site-button  button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                                <!-- SLIDE 3 -->
                                <li data-index="rs-3000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slide3.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slide3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                                id="slide-300-layer-1" 
                                data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                data-width="full"
                                data-height="full"
                                data-whitespace="nowrap"
                                data-type="shape" 
                                data-basealign="slide" 
                                data-responsive_offset="off" 
                                data-responsive="off"
                                data-frames='[{"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                
                                style="z-index: 12;background-color:rgba(0, 0, 0, 0.50);border-color:rgba(0, 0, 0, 0);border-width:0px;"> </div>
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                id="slide-300-layer-2" 
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
				data-y="['top','top','top','top']" data-voffset="['150','150','150','150']" 
				data-fontsize="['55','55','55','55']"
				data-lineheight="['60','60','60','60']"
				data-width="['800','800','800','800']"
				data-height="['none','none','none','none']"
				data-whitespace="['normal','normal','normal','normal']"

				data-type="text" 
				data-responsive_offset="on" 
				data-frames='[{"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}]'
				data-textAlign="['left','left','left','left']"
				data-paddingtop="[0,0,0,0]"
				data-paddingright="[0,0,0,0]"
				data-paddingbottom="[0,0,0,0]"
				data-paddingleft="[0,0,0,0]"

				style="z-index: 13; 
				white-space: normal; 
				font-size: 60px; 
				line-height: 60px; 
				font-weight: 700; 
				color: rgba(255, 255, 255, 1.00);
				border-width:0px;"> <span class="text-uppercase" style="font-family: Oswald;">MAKE YOUR CAR LAST LONGER</span> </div>

                                    <!-- LAYER NR. 3 [ for paragraph] -->
                                    <div class="tp-caption  tp-resizeme" 
                                id="slide-300-layer-3" 
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['250','250','250','250']"  
                                data-fontsize="['20','20','20','35']"
								data-lineheight="['30','30','30','40']"
								data-width="['800','800','800','1000']"
								data-height="['none','none','none','none']"
                                data-whitespace="['normal','normal','normal','normal']"
                     
                                data-type="text" 
                                data-responsive_offset="on"
                                data-frames='[
                                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                ]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 13; 
                                font-weight: 500; 
                                color: rgba(255, 255, 255, 0.85);
                                border-width:0px;"> <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                        text ever since the  when an unknown printer took a galley of type and scrambled [...]</span> </div>
                                    <!-- LAYER NR. 4 [ for readmore botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                id="slide-300-layer-4"						
                                data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
								data-y="['top','top','top','top']" data-voffset="['370','370','370','460']"  
                                data-fontsize="['none','none','none','none']"
								data-lineheight="['none','none','none','none']"
								data-width="['700','700','700','700']"
								data-height="['none','none','none','none']"
                                data-whitespace="['normal','normal','normal','normal']"
                                
                                data-type="text" 
                                data-responsive_offset="on"
                                data-frames='[ 
                                {"from":"y:50px(R);opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                ]'
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                
                                style="z-index: 13;"><a href="javascript:void(0);" class="site-button   button-skew"><span>Read More</span><i class="fa fa-angle-right"></i></a> </div>
                                </li>
                            </ul>
                            <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                        </div>
                    </div>
                    <!-- END REVOLUTION SLIDER -->
                </div>
            </div>
        </div>
        <!-- Slider END -->
        
        <!-- About Company -->
        <div class="section-full  bg-gray content-inner-1" style="background-image: url(images/bg-img.png); background-repeat: repeat-x; background-position: left bottom -37px;">
            <div class="container">
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-7">
                            <h2 class="text-uppercase"> About  Company</h2>
                            <div class="dlab-separator-outer ">
                                <div class="dlab-separator bg-secondry style-skew"></div>
                            </div>
                            <div class="clear"></div>
                            <p><strong>City Car Cares is a Pune based Company come garage, which is one stop shop solution for Car.
Worldclass best quality services and customer satisfaction is our aim and we have been achieving the same since we came into business. City Car Cares guarantees to SAVE 25% of your annual spending.</strong></p>
                            <p class="m-b50">It is our promise to continue to serve you better quality services each day in all the dealings that we provide under our roof. It is our determination to deliver excellent services that keeps us going and we can guarantee you that your car will be in the best hands when you bring it to our garage.<a href="about-us.php">[...]</a></p>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30 ">
                                        <div class="icon-bx-sm-custom bg-secondry "> <span class="icon-cell"><i class="fa fa-cogs text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h5 class="dlab-tilte text-uppercase">WE'RE EXPERTS</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30 ">
                                        <div class="icon-bx-sm-custom bg-secondry "> <span class="icon-cell"><i class="fa fa-users text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h5 class="dlab-tilte text-uppercase">WE'RE FRIENDLY</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm-custom bg-secondry "> <span class="icon-cell"><i class="fa fa-car text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h5 class="dlab-tilte text-uppercase">WE'RE ACCURATE</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="icon-bx-wraper left m-b30">
                                        <div class="icon-bx-sm-custom bg-secondry "> <span class="icon-cell"><i class="fa fa-trophy text-primary"></i></span> </div>
                                        <div class="icon-content">
                                            <h5 class="dlab-tilte text-uppercase">WE'RE TRUSTED</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="dlab-thu m"><img src="images/worker.png" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Company END -->
        <!-- Our Projects  -->
        <div class="section-full bg-img-fix content-inner overlay-black-middle" style="background-image:url(images/background/bg1.jpg);">
            <div class="container">
                <div class="section-head  text-center text-white">
                    <h2 class="text-uppercase">Our Projects</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-white style-skew"></div>
                    </div>
                    <p>Below are some our completed projects, we focous on customers needs and requirement.</p>
                </div>
                <div class="site-filters clearfix center  m-b40">
                    <ul class="filters" data-toggle="buttons">
                        <li data-filter="" class="btn active">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew active"><span>Show All</span></a> </li>
                        <li data-filter="home" class="btn">
                            <input type="radio" >
                            <a href="#" class="site-button-secondry button-skew"><span>Brakes</span></a> </li>
                        <li data-filter="office" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Suspension</span></a> </li>
                        <li data-filter="commercial" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Wheels</span></a> </li>
                        <li data-filter="window" class="btn">
                            <input type="radio">
                            <a href="#" class="site-button-secondry button-skew"><span>Steering	</span></a> </li>
                    </ul>
                </div>
                <div class="row">
                    <ul id="masonry" class="dlab-gallery-listing gallery-grid-4 gallery mfp-gallery m-b0">
                        <li data-filter="home" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic1.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic1.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="office" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow dlab-img-effect zoom"> <a href="javascript:void(0);"> <img src="images/our-work/pic2.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic2.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="children-aid" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic3.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a href="images/our-work/pic3.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="commercial" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic4.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic4.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="window" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic5.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic5.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li data-filter="apartment" class="card-container col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <div class="dlab-box dlab-gallery-box">
                                <div class="dlab-media dlab-img-overlay1 dlab-img-effect zoom-slow"> <a href="javascript:void(0);"> <img src="images/our-work/pic6.jpg"  alt=""> </a>
                                    <div class="overlay-bx">
                                        <div class="overlay-icon"> <a href="javascript:void(0);"> <i class="fa fa-link icon-bx-xs"></i> </a> <a  href="images/our-work/pic6.jpg" class="mfp-link"  title="Image title come here"> <i class="fa fa-picture-o icon-bx-xs"></i> </a> </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Our Projects END -->
        <!-- OUR SERVICES -->
        <div class="section-full  bg-white content-inner overlay-white-middle" style="background-image:url(images/background/bg5.png); background-position:right center; background-repeat:no-repeat; background-size: auto 100%;">
            <div class="container">
                <div class="section-head text-center">
                    <h2 class="text-uppercase"> OUR SERVICES</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-secondry style-skew"></div>
                    </div>
                    <p>City Car Cares offer an extensive range of car servicing. From the standard car service, to scheduled log book services and specific servicing on integral parts of your car including the below;</p>
                </div>
                <div class="section-content">
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-life-saver text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">AIR CONDITIONING</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-car text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">BRAKE REPAIR</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-thumbs-up text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">LUBE, OIL AND FILTERS</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-trophy text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">BELTS AND HOSES</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b40">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-cubes text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">ENGINE DIAGNOSTICS</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="icon-bx-wraper center m-b10">
                            <div class="icon-bx-sm bg-secondry m-b20"> <span class="icon-cell"><i class="fa fa-area-chart text-primary"></i></span> </div>
                            <div class="icon-content">
                                <h5 class="dlab-tilte text-uppercase">TIRE AND WHEEL SERVICES</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- OUR SERVICES END-->
        <!-- Company staus -->
        <div class="section-full text-white bg-img-fix content-inner overlay-black-middle" style="background-image:url(images/background/bg4.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-building-o m-r20"></i> <span class="counter">10</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Active Experts</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-group m-r20"></i> <span class="counter">1226</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Happy Client</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b30">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-slideshare m-r20"></i> <span class="counter">20</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Car Serviced Every Day</span></h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="dex-box text-primary border-2 counter-box m-b10">
                            <h2 class="text-uppercase m-a0 p-a15 "><i class="fa fa-home m-r20"></i> <span class="counter">1156</span></h2>
                            <h5 class="dlab-tilte  text-uppercase m-a0"><span class="dlab-tilte-inner skew-title bg-primary p-lr15 p-tb10">Completed Project</span></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Company staus END -->
        <!-- Testimonials blog -->
        <div class="section-full overlay-black-middle bg-img-fix content-inner-1" style="background-image:url(images/background/bg2.jpg);">
            <div class="container">
                <div class="section-head text-white text-center">
                    <h2 class="text-uppercase">What peolpe are saying</h2>
                    <div class="dlab-separator-outer ">
                        <div class="dlab-separator bg-white  style-skew"></div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="testimonial-four">
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>I got my Audi A4 serviced from City Car Care, at first I was a bit sceptical about quality but was quite impressed with their way of handling everything. The service was done in just 12000 Rs only which is nearly half of cost given by Audi service centre.</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>My swift had some dents & scratches on front bumper. Maruti service station gave me an estimate of 5K & surprisingly City Car Care repaired my car in just Rs 2200, very good job CCC,you have got one more happy customer.</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-4 testimonial-bg">
                                <div class="testimonial-pic"><img src="images/testimonials/pic1.jpg" width="100" height="100" alt=""></div>
                                <div class="testimonial-text">
                                    <p>My car had some electrical issue, the service executive came at my place to examine the car and I was very surprised when the price quoted by him was much lesser than the estimate given by Honda service station. I am very happy with the work done on my car, thank you City Car Cares.</p>
                                </div>
                                <div class="testimonial-detail"> <strong class="testimonial-name">David Matin</strong> <span class="testimonial-position">Student</span> </div>
                                <div class="quote-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonials blog END -->
        <!-- Client logo -->
        <div class="section-full dlab-we-find bg-img-fix p-t50 p-b50 ">
            <div class="container">
                <div class="section-content">
                    <div class="client-logo-carousel mfp-gallery gallery owl-btn-center-lr">
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Volkswagen.png" title="Volkswagen"></div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Audi.png" title="Audi"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/BMW.png" title="BMW"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Chevrolet.png" title="Chevrolet"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Datsun.png" title="Datsun"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Fiat.png" title="Fiat"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Ford.png" title="Ford"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Honda.png" title="Honda"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Hyundai.png" title="Hyundai"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Jaguar.png" title="Jaguar"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Maruti Suzuki.png" title="Maruti Suzuki"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Mercedes.png" title="Mercedes"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Nissan.png" title="Nissan"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Renault.png" title="Renault"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Skoda.png" title="Skoda"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Tata.png" title="Tata"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Toyota.png" title="Toyota"> </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ow-client-logo">
                                <div class="client-logo"><img src="images/brands/Volvo.png" title="Volvo"> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Client logo END -->
    </div>
    <!-- Content END-->
    
<?php 
	include('footer.php');
?>