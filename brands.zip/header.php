<?php
$requestUri     = $_SERVER['REQUEST_URI'];
$indexClass     = ''; $whyUsClass     = ''; $abtUsClass     = ''; $serviceClass   = ''; $galleryClass   = ''; $contactUsClass = '';
$title          = 'City Car Cares - Pune';
$serviceArray   = array('/citycar/all-service.php','/citycar/engine-diagnostics.php','/citycar/lube-oil-and-filters.php','/citycar/belts-and-hoses.php','/citycar/air-conditioning.php','/citycar/brake-repair.php','/citycar/tire-and-wheel-services.php');
$indexArray = array('/citycar/index.php','/citycar/');

if(in_array($requestUri,$indexArray))
{
  $indexClass = 'class="active"';
}

if($requestUri == '/citycar/why-us.php')
{
  $whyUsClass = 'class="active"';
  $title      = 'Why City Car Cares - Pune';
}

if($requestUri == '/citycar/about-us.php')
{
  $abtUsClass = 'class="active"';
  $title      = 'About City Car Cares - Pune';
}

if(in_array($requestUri,$serviceArray))
{
  $serviceClass = 'class="active"';
  $title        = 'Services by City Car Cares - Pune';
}

if($requestUri == '/citycar/gallery.php')
{
  $galleryClass = 'class="active"';
  $title        = 'Gallery of City Car Cares - Pune';
}

if($requestUri == '/citycar/contact-us.php')
{
  $contactUsClass = 'class="active"';
  $title          = 'Contact to City Car Cares - Pune';
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	  <!-- Page Title Here -->
	  <title>
	    <?php echo $title; ?>
	  </title>

	  <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="keywords" content="" />
	  <meta name="author" content="" />
	  <meta name="robots" content="" />
	  <meta name="description" content="City Car Cares is well designed creating websites of automotive repair shops, stores with spare parts and accessories for car repairs, car washes, car danting and panting, service stations, car showrooms painting, major auto centers and other sites related to cars and car services." />
	  <meta property="og:title" content="City Car Cares - Car Services Template" />
	  <meta property="og:description" content="City Car Cares is well designed creating websites of automotive repair shops, stores with spare parts and accessories for car repairs, car washes, car danting and panting, service stations, car showrooms painting, major auto centers and other sites related to cars and car services." />
	  <meta property="og:image" content="social-image.png" />

	  <meta name="format-detection" content="telephone=no">

	  <!-- Favicons Icon -->
	  <link rel="icon" href="https://s3.ap-south-1.amazonaws.com/dlab-html/autocare/xhtml/images/favicon.ico" type="image/x-icon" />
	  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />

	  <!-- Mobile Specific -->
	  <meta name="viewport" content="width=device-width, initial-scale=1">

	  <!-- Stylesheets -->
	  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	  <link rel="stylesheet" type="text/css" href="css/custom-css.css">
	  <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
	  <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	  <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
	  <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
	  <link rel="stylesheet" type="text/css" href="css/style.min.css">
	  <link class="skin"  rel="stylesheet" type="text/css" href="css/skin/skin-1.css">
	  <link  rel="stylesheet" type="text/css" href="css/templete.css">
	  <link rel="stylesheet" type="text/css" href="css/switcher.min.css">

	  <!-- Google Analytic Code -->
	  <!-- Global site tag (gtag.js) - Google Analytics -->
	  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-120201663-1">
	  </script>
	  <script>
	    window.dataLayer = window.dataLayer || [];
	    function gtag()
	    {
	      dataLayer.push(arguments);
	    }
	    gtag('js', new Date());

	    gtag('config', 'UA-120201663-1');
	  </script>
	  <!-- Google Analytic Code --><!-- Revolution Slider Css -->
	  <link rel="stylesheet" type="text/css" href="plugins/revolution/css/settings.min.css">
	  <!-- Revolution Navigation Style -->
	  <link rel="stylesheet" type="text/css" href="plugins/revolution/css/navigation.min.css">
	  <!-- Google fonts -->
	  <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800,900|Nunito:200,300,400,600,700,800,900|Open+Sans:300,400,600,700,800|Oswald:200,300,400,500,600,700|PT+Serif:400,700|Quicksand:300,400,500,700|Roboto+Slab:100,300,400|Roboto:100,300,400,500,700,900" rel="stylesheet">
	</head>
	<body id="bg">
		<div id="loading-area">
		</div>
		<div class="page-wraper">
			<!-- header -->
			<header class="site-header header-style-1">
			  <!-- top bar -->
			  <div class="top-bar">
			    <div class="container">
			      <div class="row">
			        <div class="dlab-topbar-left">
			        </div>
			        <div class="dlab-topbar-right">
			          <ul class="social-bx list-inline pull-right">
			            <li>
			              <a href="javascript:void(0);" class="fa fa-facebook">
			              </a>
			            </li>
			            <li>
			              <a href="javascript:void(0);" class="fa fa-twitter">
			              </a>
			            </li>
			            <li>
			              <a href="javascript:void(0);" class="fa fa-linkedin">
			              </a>
			            </li>
			            <li>
			              <a href="javascript:void(0);" class="fa fa-google-plus">
			              </a>
			            </li>
			          </ul>
			        </div>
			      </div>
			    </div>
			  </div>
			  <!-- top bar END-->
			  <!-- main header -->
			  <div class="sticky-header header-curve main-bar-wraper">
			    <div class="main-bar bg-primary clearfix ">
			      <div class="container clearfix">
			        <!-- website logo -->
			        <div class="logo-header mostion">
			          <a href="index.php">
			            <img src="images/logo.png" width="193" height="89" alt="">
			          </a>
			        </div>
			        <!-- nav toggle button -->
			        <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
			          <span class="sr-only">
			            Toggle navigation
			          </span>
			          <span class="icon-bar">
			          </span>
			          <span class="icon-bar">
			          </span>
			          <span class="icon-bar">
			          </span>
			        </button>
			        <!-- extra nav -->
			        <div class="extra-nav">
			          <div class="extra-cell">
			            <button id="quik-search-btn" type="button" class="site-button">
			              <i class="fa fa-search">
			              </i>
			            </button>
			          </div>
			        </div>
			        <!-- Quik search -->
			        <div class="dlab-quik-search bg-primary">
			          <form action="#">
			            <input name="search" value="" type="text" class="form-control" placeholder="Type to search">
			            <span id="quik-search-remove">
			              <i class="fa fa-remove">
			              </i>
			            </span>
			          </form>
			        </div>
			        <!-- main nav -->
			        <div class="header-nav navbar-collapse collapse">
			          <!-- main nav -->
			          <ul class=" nav navbar-nav">
			            <li <?php echo $indexClass; ?>>
			              <a href="index.php">
			                Home
			              </a>
			            </li>
			            <li <?php echo $whyUsClass; ?>>
			              <a href="why-us.php">
			                WHY US
			              </a>
			            </li>
			            <li <?php echo $abtUsClass; ?>>
			              <a href="about-us.php">
			                ABOUT US
			              </a>
			            </li>
			            <li <?php echo $serviceClass; ?>>
			              <a href="javascript:;">
			                SERVICES
			                <i class="fa fa-chevron-down">
			                </i>
			              </a>
			              <ul class="sub-menu">
			                <li>
			                  <a href="all-service.php">
			                    All Service
			                  </a>
			                </li>
			                <li>
			                  <a href="engine-diagnostics.php">
			                    Engine Diagnostics
			                  </a>
			                </li>
			                <li>
			                  <a href="lube-oil-and-filters.php">
			                    Lube Oil And Filters
			                  </a>
			                </li>
			                <li>
			                  <a href="belts-and-hoses.php">
			                    Belts And Hoses
			                  </a>
			                </li>
			                <li>
			                  <a href="air-conditioning.php">
			                    Air Conditioning
			                  </a>
			                </li>
			                <li>
			                  <a href="brake-repair.php">
			                    Brake Repair
			                  </a>
			                </li>
			                <li>
			                  <a href="tire-and-wheel-services.php">
			                    Tire And Wheel Services
			                  </a>
			                </li>
			              </ul>
			            </li>
			            <!--<li> <a href="index.php">TESTIMONIALS</a></li>-->
			            <li <?php echo $galleryClass; ?>>
			              <a href="gallery.php">
			                GALLERY
			              </a>
			            </li>
			            <li <?php echo $contactUsClass; ?>>
			              <a href="contact-us.php">
			                CONTACT US
			              </a>
			            </li>
			          </ul>
			          <!-- main-nav END -->
			        </div>
			      </div>
			    </div>
			  </div>
			  <!-- main header END -->
			</header>
			<!-- header END -->