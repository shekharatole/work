$(document).ready(function () {
        $('#login').validate({
            rules: {
                uname: {
                    required: true,
                    remote: {
//                        url: 'http://localhost/adityagold/chk-username',
                        url: '<?php echo base_url(); ?>chk-username',
                        method: 'post'
                    }
                },
                password: {
                    required: true,
                    remote: {
//                        url: 'http://localhost/adityagold/chk-password',
                        url: '<?php echo base_url(); ?>chk-password',
                        method: 'post'
                    }
                }
            },
            messages: {
                uname: {
                    required: "Please Enter User name.",
                    remote: "Please Enter valid user name"
                },
                password: {
                    required: "Please Enter Password.",
                    remote: "Please Enter valid password."
                }
            }
        });
    });