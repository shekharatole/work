<!DOCTYPE html>

<style>
    .error{
        color: red;
    }
</style>

<html lang="en">
    <body>

        <div id="wrapper">
            <!----------------------------------------Start Header----------------------------------->
            <?php $this->load->view("admin/header"); ?>
            <!--------------------------------------End Header----------------------------------->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Add New Business</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">

                    <?php if ($status == 1) { ?>

                        <div class="alert alert-success">
                            <strong>Success!!</strong> Your Business has registered successfully.
                        </div>
                    <?php } ?>



                    <div class="">
                        <form  id="addshop" name="addshop" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="form-group">
                                <label for="email">Shop Name:</label>
                                <input type="textbox" class="form-control" id="shopname" placeholder="Enter shop Name" name="shopname">
                            </div>
                            <div class="form-group">
                                <label for="pwd">Shop Code:</label>
                                <input type="textbox" class="form-control" id="pwd" placeholder="Enter shop code" name="shopcode">
                            </div>

                            <div class="form-group">
                                <label for="pwd">Shop Type:</label>
                                <input type="textbox" class="form-control" id="shopcode" placeholder="Enter type" name="shoptype">
                            </div>

                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>


                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-----------------------------------Start Footer-------------------------------->
        <?php $this->load->view("admin/footer"); ?>

        <!-------------------------------------End Footer-------------------------------------->
    </body>

</html>

<script>
    $(document).ready(function () {
        $('#addshop').validate({
            rules: {
                shopcode: {
                    required: true
                },
                shopname: {
                    required: true
                },
                shoptype: {
                    required: true
                }
            },
            messages: {
                shopcode: {
                    required: "Please Enter shopcode name."
                },
                shopname: {
                    required: "Please Enter shop name."
                },
                shoptype: {
                    required: "Please Enter shop Type."
                }
            }
        });
    });

window.setTimeout(function() {
    $(".alert").fadeTo(50, 0).slideUp(50, function(){
        $(this).remove(); 
    });
}, 1000);
</script>