

<div><strong>powered by PixyCloud System</strong></div>

<!--<script type="text/javascript" src="http://www.socialannex.com/public/datepicker/ui/ui.core.js"></script>-->
<!--<script type="text/javascript" src="http://www.socialannex.com/public/datepicker/ui/ui.datepicker.js"></script>-->
<!-- jQuery -->
<script src="<?php echo base_url(); ?>media/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url(); ?>media/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url(); ?>media/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url(); ?>media/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>media/vendor/morrisjs/morris.min.js"></script>
<!--<script src="<?php echo base_url(); ?>media/data/morris-data.js"></script>-->

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url(); ?>media/dist/js/sb-admin-2.js"></script>
<script src="<?php echo base_url(); ?>media/js/jquery.validate.js"></script>
<script src="<?php echo base_url(); ?>media/js/jquery-ui.js"></script>