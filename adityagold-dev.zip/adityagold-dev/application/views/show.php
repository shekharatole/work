

<div><h3>Show Users</h3></div>

<table border="1">

    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Address</th>
        <th>Email</th>
        <th>PhNo</th>
    </tr>


    <?php foreach ($userinfo as $val) { ?>
        <tr>
            <td> <?php echo $val['id']; ?></td>
            <td> <?php echo $val['name']; ?></td>
            <td> <?php echo $val['address']; ?></td>
            <td> <?php echo $val['email']; ?></td>
            <td> <?php echo $val['phno']; ?></td>
        </tr>

    <?php }
    ?>



</table>


