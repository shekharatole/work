<!DOCTYPE html>


<style>
    .error{
        color: red;
    }
</style>
<html lang="en">
    <body>

        <div id="wrapper">
            <!--Start Header-->
            <?php $this->load->view("admin/header"); ?>
            <!--End Header-->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Add User</h3>
                    </div>
                </div>
                
                <div class="row">
                    <div class="">
                        <?php if ($status == 1) { ?>
                            <div class="alert alert-success">
                                <strong>Success!!</strong> User has added successfully.
                            </div>
                        <?php } ?>

                        <form id="adduser" name="expense" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="col-lg-6">
                                <label for="email">First Name:</label>
                                <input type="textbox" class="form-control" id="firstname" placeholder="Enter First Name" name="firstname">
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="pwd">Last Name:</label>
                                <input type="textbox" class="form-control" id="lastname" placeholder="Enter Last Name" name="lastname">
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="pwd">Email:</label>
                                <input type="textbox" class="form-control" id="email" placeholder="Enter Email Address" name="email">
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="pwd">Mobile:</label>
                                <input type="textbox" class="form-control" id="mobile" placeholder="Enter Mobile Number" name="mobile">
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="pwd">Birth Date:</label>
                                <input type = "text" class="form-control" name="bdate" id = "datepicker-1" placeholder="Please Select Date">
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="pwd">Address:</label>
                                <input type="textbox" class="form-control" id="address" placeholder="Enter Address" name="address">
                            </div>

                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--Start Footer-->
        <?php $this->load->view("admin/footer"); ?>

        <!--End Footer-->
    </body>
</html>

<script>
    $(document).ready(function () {
        $.validator.addMethod("valueNotEquals", function (value, element, arg) {
            return arg !== value;
        }, "Value must not equal arg.");

        $('#adduser').validate({
            rules: {
                firstname: {
                    required: true
                },
                lastname: {
                    required: true
                },
                email: {
                    required: true,
                    email: true,
                    remote: {
                        url: '<?php echo base_url(); ?>chkemail',
                        method: 'post'
                    }
                },
                mobile:{
                    required: true,
                    digits:true,
                    minlength: 10,
                    maxlength: 10,
                    remote: {
                        url: '<?php echo base_url(); ?>chkmobile',
                        method: 'post'
                    }
                },
                bdate: {
                    required: true
                },
                address:{
                    required: true
                }
            },
            messages: {
                firstname: {
                    required: "Please enter your first name."
                },
                lastname: {
                    required: "Please enter your last name."
                },
                email: {
                    required: "Please enter email adress.",
                    email: "Your email address must be in the format of name@domain.com",
                    remote: "This email is already exist."
                },
                mobile: {
                    required: "Please enter mobile number.",
                    digits: "Please enter only numeric value.",
                    minlength: "Please enter valid 10 digit mobile number.",
                    maxlength: "Please enter valid 10 digit mobile number.",
                    remote: "This mobile number is already exist."
                },
                bdate: {
                    required: "Please select date."
                },
                address: {
                    required: "Please enter your address."
                }
            }
        });
    });

    window.setTimeout(function () {
        $(".alert").fadeTo(50, 0).slideUp(50, function () {
            $(this).remove();
        });
    }, 1500);

</script>
<script src="<?php echo base_url(); ?>media/js/datevalidation.js"></script>