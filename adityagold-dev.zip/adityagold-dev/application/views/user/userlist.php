<!DOCTYPE html>
<style>
    .tatal{
        float: left;
        font-family: fantasy;
        font-size: 18px;
    }
    .hr{
        margin-top: 20px;
        margin-bottom: 20px;
        border: 12;
        border-color: red;
        border-top: 1px solid #eee;
    }

</style>
<link href="<?php echo base_url(); ?>media/css/pagination.css" rel="stylesheet">
<?php
//echo $pagination;
if ($start != '') {
    $txtFromDate = date('m/d/Y', strtotime($start));
} else {
    $txtFromDate = date('m/d/Y', strtotime(date('m/d/Y') . " -1 month"));
}

if ($end) {
    $txtToDate = date('m/d/Y', strtotime($end));
} else {
    $txtToDate = date('m/d/Y');
}
?>

<html lang="en">
    <body>
        <div id="wrapper">
            <!--Start Header-->
            <?php $this->load->view("admin/header"); ?>
            <!--End Header-->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">User Detail's</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row col-md-12">
                    <form name="search" method="post">
                        <div>
                            <div class="col-md-3 col-sm-3">
                                <input type = "text" class="form-control" autocomplete="off" name="start" id = "from_date" value="<?php echo ($txtFromDate != "") ? $txtFromDate : date('m/d/Y'); ?>" placeholder="Please Select Start Date">
                            </div>
                        </div>
                        <div> 
                            <div class="col-md-3 col-sm-3">
                                <input type = "text" class="form-control" autocomplete="off" name="end" id = "to_date" value="<?php echo ($txtToDate != "") ? $txtToDate : date('m/d/Y'); ?>" placeholder="Please Select End Date">
                            </div>
                        </div>
                        <div class="col-md-1 col-sm-1">
                            <input type="submit" name="submit" value="submit">
                        </div>
                    </form>
                </div>
                <br><br><br><br>
                <div class="row">

                    <div class="col-lg-12 col-md-12">
                        <h4> <strong> User List.</strong></h4>    
                        <table id="expense" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>DOB</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                if (count($userlist) > 0) {
                                    foreach ($userlist as $val) {
                                        ?>
                                        <tr>
                                            <td><?php echo $val['firstname']; ?></td>
                                            <td><?php echo $val['lastname']; ?></td>
                                            <td><?php echo $val['email']; ?></td>
                                            <td><?php echo $val['mobile']; ?></td>
                                            <td><?php echo date("d-m-Y", strtotime($val['bdate'])); ?></td>
                                            <td><?php echo $val['address']; ?></td>
                                            <td><?php if($val['status'] == '0'){ $userStatus= 'Inactive'; }else{ $userStatus= 'Active'; } echo $userStatus; ?></td>
                                            <td><a href="<?php echo base_url('user/edituser/' . $val['id']); ?>">EDIT</a>&nbsp;&nbsp;<a href="<?php echo base_url('user/deleteuser/' . $val['id']); ?>">DELETE</a></td>

                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-4"></div>
                        <div class="col-lg-6">
                            <div id="pagination">
                                <ul class="tsc_pagination">
                                    <!-- Show pagination links -->
                                    <?php
                                    foreach ($pagination as $pagination) {
                                        echo "<li>" . $pagination . "</li>";
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12"> <hr class="hr"></div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!--Start Footer-->
        <?php $this->load->view("admin/footer"); ?>
        <!--End Footer-->
    </body>
</html>
<script src="<?php echo base_url(); ?>media/js/datevalidation.js"></script>