<?php

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insertdata($tablename, $data) {
        $this->db->insert($tablename, $data);
        return $this->db->insert_id();
    }

    public function updaterow($tablename, $condition, $updatedata) {
        if ($condition != '') {
            foreach ($condition as $field => $value) {
                $this->db->where($field, $value);
            }
        }
        $this->db->update($tablename, $updatedata);
    }

    public function deleterow($tablename, $condition) {
        if ($condition != '') {
            foreach ($condition as $field => $value) {
                $this->db->where($field, $value);
            }
        }
        $this->db->delete($tablename);
    }

    public function getRecords($tablename, $fields, $condition) {
        if (count($fields) > 0) {
            if ($fields != ''){
                $field = implode(",", $fields);
            }
        }else {
            $field = '*';
        }
        if (count($condition)) {
            foreach ($condition as $fieldname => $fieldval) {
                $this->db->where($fieldname, $fieldval);
            }
        } elseif ($condition != '') {
            $this->db->where($condition);
        }
        $this->db->select($field);
        $this->db->from($tablename);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function getRecordsEdit($tablename, $field, $condition){        
        $this->db->select($field);
        $this->db->from($tablename);
        $this->db->where($condition);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getUserList($startdate, $enddate, $limit, $offset, $shop_id = "") {
        $condition = $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND expenditure.shop_id=$shop_id";
        }
        //$condition = " expenditure.id = ".$id;
        $condition .= " is_delete = '0' AND db_add_date BETWEEN '$startdate 00:00:00' AND '$enddate 23:59:59' " . $shopCondition;
        
        $this->db->select('*');
        $this->db->from('user_registration');
        $this->db->where($condition);
        $this->db->limit($limit,$offset);
        //die($condition);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function getSingleUserList($id){
        $condition = ' id = '.$id;
        $this->db->select('*');
        $this->db->from('user_registration');
        $this->db->where($condition);
        $query = $this->db->get();
        return $query->result_array();
    }
}
