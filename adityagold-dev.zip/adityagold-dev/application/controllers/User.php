<?php

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("user_model");
    }

    public function index() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $this->load->view("user/dashboard");
    }

    public function adduser() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        $firstname = $this->input->post('firstname');
        $lastname = $this->input->post('lastname');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $bdate = $this->input->post('bdate');
        $address = $this->input->post('address');

        if ($firstname != '' && $lastname != '' && $email != '') {
            $insertArray = array('firstname' => $firstname, 'lastname' => $lastname, 'email' => $email, 'mobile'=>$mobile, 'bdate' => date("Y-m-d", strtotime($bdate)), 'address'=>$address);
            $insertid = $data = $this->user_model->insertdata("user_registration", $insertArray);
            if ($insertid > 0){
                $dataArray['status'] = 1;
            }
        }
        //$dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        $this->load->view("user/adduser", $dataArray);
    }
    
    public function chkemail() {
        if($this->input->post("userid")){
            $emailCondition = " email = '".$this->input->post('email')."' AND email != '".$this->input->post("useremail")."' ";
            $data = $this->user_model->getRecordsEdit("user_registration",'id', $emailCondition);
        }else{
            $data = $this->user_model->getRecords("user_registration", array('email'), array('email' => $this->input->post('email')));
        }
        if (count($data) > 0) {
            echo "false";
        } else {
            echo "true";
        }
    }
    
    public function chkmobile() {
        if($this->input->post("userid")){
            $mobileCondition = " mobile = '".$this->input->post('mobile')."' AND mobile != '".$this->input->post("usermobile")."' ";
            $data = $this->user_model->getRecordsEdit("user_registration",'id', $mobileCondition);
        }else{
           $data = $this->user_model->getRecords("user_registration", array('mobile'), array('mobile' => $this->input->post('mobile'))); 
        }
        if (count($data) > 0) {
            echo "false";
        } else {
            echo "true";
        }
    }

    public function userlist($pageoffset = 0) {

        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        
        if ($this->input->post("start") != '' && $this->input->post("end")) {
            $start = date("Y-m-d", strtotime($this->input->post("start")));
            $end = date("Y-m-d", strtotime($this->input->post("end")));
        } else {
            $start = date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"));
            $end = date('Y-m-d');
        }
        
        $expenseCondition = " db_add_date BETWEEN '$start' AND '$end' ";
        $totalCount = $this->common_model->getPaginationCount("user_registration", $fields = array('id'), $expenseCondition);        
        
        /* pagination */
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'user/userlist';
        $config['total_rows'] = $totalCount;
        $config['per_page'] = 10;

        $config['cur_tag_open'] = '<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        $pagination = $this->pagination->create_links();
        $data["links"] = explode('&nbsp;',$pagination );
        $dataArray['pagination'] = $data["links"];
        
        print_r($dataArray);
        die();
        /*End*/      
        
        $dataArray['userlist'] = $this->user_model->getUserList($start, $end, $config["per_page"], $pageoffset,'');              
        $dataArray['start'] = $start;
        $dataArray['end'] = $end;
        $this->load->view("user/userlist", $dataArray);
    }
    
    public function deleteuser($id=null)
    {
        $this->user_model->updaterow("user_registration", array('id' => $id), array('is_delete' => '1'));
        redirect(base_url().'userlist');
    }    
    
    public function edituser($id=null)
    {
        if($this->input->post("userid")){
            $userid = $this->input->post("userid");
            $firstname = $this->input->post('firstname');
            $lastname = $this->input->post('lastname');
            $email = $this->input->post('email');
            $mobile = $this->input->post('mobile');
            $bdate = $this->input->post('bdate');
            $address = $this->input->post('address');
            $userstatus = $this->input->post('userstatus');
            
            $this->user_model->updaterow("user_registration", array('id' => $userid), array('firstname' => $firstname, 'lastname' => $lastname, 'email' => $email, 'mobile'=>$mobile, 'bdate' => date("Y-m-d", strtotime($bdate)), 'address'=>$address,'status'=>$userstatus));
            redirect(base_url().'userlist');
        }else{
            $dataArray['status'] = 0;
            $dataArray['userdata'] = $this->user_model->getSingleUserList($id); 
            $this->load->view("user/edituser", $dataArray);
        }
    }
}
