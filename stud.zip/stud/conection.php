<?php
//$con = mysql_connect("localhost","root","technology");
//if (!$con)
//  {
//  die('Could not connect: ' . mysql_error());
//  }
//
//mysql_select_db("studentinfo", $con);

// Create connection
$con = new mysqli("localhost","root", "","studentinfo");
// Check connection
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
} 
?>
