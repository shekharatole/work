<?php
session_start(); 
include("header.php"); 
include("conection.php");

$result = $con->query("SELECT * FROM studentdetails WHERE studid='$_SESSION[userid]'");
 while($row1 = $result->fetch_array(MYSQLI_ASSOC))
  {
		$studid = $row1['studid'];
		$username = $row1['username'];
		$studfname = $row1['studfname'];
		$studlname = $row1['studlname'];
		$fathername = $row1['fathername'];
		$address = $row1['address'];
		$contactno = $row1['contactno'];
		$semester = $row1['semester'];
  }
/*  $result12 = $con->query("SELECT * FROM course WHERE courseid 	='$couseid'");
 while($row2 = $result12->fetch_array(MYSQLI_ASSOC))
  {
	  $cbane =	  $row2['coursename'];
  }*/
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
</h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader">
  <h2>Lecture Profile</h2>
  </header>
  <section class="entry">
  <font size="3">
  <form action="" method="post" class="form">
   <table width="501" height="228" border="1">
     <tr>
       <td width="198" height="34"><strong>&nbsp; Student ID :</strong></td>
       <td width="287">&nbsp; <?php echo $studid ;?></td>
     </tr>
     <tr>
       <td height="42"><strong>&nbsp;  Username :</strong></td>
       <td>&nbsp;<?php echo $username ;?></td>
     </tr>
     <tr>
       <td height="42"><strong>&nbsp;  First Name :</strong></td>
       <td>&nbsp;<?php echo $studfname ;?></td>
     </tr>
     <tr>
       <td height="64"><strong>&nbsp; Middle Name : </strong></td>
       <td>&nbsp; <?php echo $fathername ;?></td>
     </tr <tr>
       <td height="64"><strong>&nbsp; Last Name : </strong></td>
       <td>&nbsp; <?php echo $studlname ;?></td>
     </tr <tr>
       <td height="64"><strong>&nbsp; Address : </strong></td>
       <td>&nbsp; <?php echo $address ;?></td>
     </tr>
     <tr>
       <td height="39"><strong>&nbsp; Contact No. : </strong></td>
       <td>&nbsp; <?php echo $contactno;?></td>
     </tr>
     <tr>
       <td height="35"><strong>&nbsp; Semester :</strong></td>
       <td>&nbsp; <?php echo $semester ;?></td>
     </tr>
   </table>
     </font>
   <p class="textfield">&nbsp;</p>
<div class="clear"></div>
</form>
  </section>
</article>

<article class="post">
  <header class="postheader"></header>
  <section class="entry">
    <form action="" method="post" class="form">
<div class="clear"></div>
</form>
<div class="clear"></div>
</section>
</article>



</section>


<?php 
if($_SESSION["type"]=="admin"){
		include("adminmenu.php");
} elseif($_SESSION["type"]=="student"){
 	include("studmenu.php");
}else{	
	include("lecturemenu.php");
}

include("footer.php"); ?>