<?php 
session_start();
//echo $_SESSION["uid"];
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="admin")
	{
		header("Location: dashboard.php");
	}
	elseif($_SESSION["type"]=="lecture")
	{	
		header("Location: lectureaccount.php");
	}else{
		header("Location: studentaccount.php");
	}
}

include("header.php"); 
include("conection.php");
if(isset($_POST["uid"]) && isset($_POST["pwd"]) )
{
//	echo "sdfsd".	$_POST[uid];
$result = $con->query("SELECT * FROM administrator WHERE adminid='$_POST[uid]' OR adminname = '$_POST[uid]' ");
while($row = $result->fetch_array(MYSQLI_ASSOC))
  {
		$pwdmd5 = $row["password"];		
		$_SESSION["userid"] = $row["adminid"];
  }

	if(md5($_POST["pwd"])==$pwdmd5)
	//if($_POST["pwd"]==$pwdmd5)
	{
		$_SESSION["type"]="admin";
		header("Location: dashboard.php");
	}
	else
	{
		$log =  "Login failed.. Please try again..";
	}
}

if(isset($_POST["luid"]) && isset($_POST["lpwd"]))
{
$result = $con->query("SELECT * FROM lectures WHERE lecid='$_POST[luid]' OR lecname = '$_POST[luid]'");
	while($row = $result->fetch_array(MYSQLI_ASSOC))
 	{
		$pwdm= $row["password"];
		$_SESSION["lecname"] = $row["lecname"];
		$_SESSION["coid"] = $row["courseid"];
		$_SESSION["userid"] = $row['lecid'];
		$_SESSION["type"]="lecture";
  }
//echo"pwd". md5($_POST["lpwd"]);

if(md5($_POST["lpwd"])==$pwdm)
	{
		//echo $_POST["lpwd"];
	//$_SESSION["userid"] = $_POST["luid"];
	$_SESSION["type"]=="lecturer";
	header("Location: lectureaccount.php");
	}
else
	{
		$log12 =  "Login failed.. Please try again..";
	}
}

if(isset($_POST["suid"]) && isset($_POST["spwd"]))
{
$result = $con->query("SELECT * FROM studentdetails WHERE username='$_POST[suid]' ");
	while($row = $result->fetch_array(MYSQLI_ASSOC))
 	{
		$pwdm= $row["password"];
		$_SESSION["sname"] = $row["studfname"];
		$_SESSION["type"]="student";		
		$_SESSION["userid"] = $row['studid'];
  }
//echo"pwd". md5($_POST["lpwd"]);

if(md5(@$_POST["spwd"])==$pwdm)
	{
		//echo $_POST["lpwd"];
	//$_SESSION["userid"] = $_POST["luid"];
	$_SESSION["type"]=="student";
	header("Location: studentaccount.php");
	}
else
	{
		$log123 =  "Login failed.. Please try again..";
	}
}
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
</h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader">
  <h2><u>Admin Login</u></h2>
  <h2><?php echo @$log;?></h2>
  </header>
  <section class="entry">
  <form action="admin.php" method="post" class="form">
   <p class="textfield">
      <label for="author">
             <small>Admin Login ID (required)</small>
          </label>
           <input name="uid" id="uid" value="" size="22" tabindex="1" type="text">
   </p>
   <p class="textfield">
   <label for="email">
              <small>Password (required)</small>
          </label>
       <input name="pwd" id="pwd" value="" size="22" tabindex="2" type="password">
   </p>
   <p>
     <input name="submit" id="submit" tabindex="3" type="image" src="images/submit.png">
     <input name="comment_post_ID" value="1" type="hidden">
     
   </p>
   <div class="clear"></div>
</form>
  <form action="admin.php" method="post" class="form">
<div class="clear">
<hr />
  <header class="postheader">
    <h2><u>Lectures Login</u></h2>
    <h2><?php echo @$log12;?></h2>
  </header>
  <section class="entry">

      <p class="textfield">
        <label for="author2"> <small><br />
          Lecture Login ID (required)</small> </label>
        <input name="luid" id="luid" value="" size="22" tabindex="4" type="text" />
      </p>
      <p class="textfield">
        <label for="email2"> <small>Password (required)</small> </label>
        <input name="lpwd" id="lpwd" size="22" tabindex="5" type="password" />
      </p>
      <p>
        <input name="submit2" id="submit2" tabindex="6" type="image" src="images/submit.png" />
        <input name="comment_post_ID2" value="1" type="hidden" />
      </p>
      <div class="clear"></div>
    </form>
    <div class="clear"></div>
    
    <!-- Student -->
    
    <form action="admin.php" method="post" class="form">
<div class="clear">
<hr />
  <header class="postheader">
    <h2><u>Student Login</u></h2>
    <h2><?php echo @$log123;?></h2>
  </header>
  <section class="entry">

      <p class="textfield">
        <label for="author3"> <small><br />
          Student Login ID (required)</small> </label>
        <input name="suid" id="suid" value="" size="22" tabindex="7" type="text" />
      </p>
      <p class="textfield">
        <label for="email2"> <small>Password (required)</small> </label>
        <input name="spwd" id="spwd" size="22" tabindex="8" type="password" />
      </p>
      <p>
        <input name="submit3" id="submit3" tabindex="9" type="image" src="images/submit.png" />
        <input name="comment_post_ID3" value="1" type="hidden" />
      </p>
      <div class="clear"></div>
    </form>
    <div class="clear"></div>
    
  </section>
</div>
</section>
</article>
</section>

<?php 
include("adminmenu.php");
include("footer.php"); ?>