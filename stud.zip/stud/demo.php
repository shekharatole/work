<?php 
session_start();

include("header.php"); 
include("conection.php");
include("modal.php");
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
Course Details.  </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader">
  <h2>Course Details</h2>
  </header>
  <section class="entry">
  <font color="#330000">
   
   <!-- put code here ---- -->
  </section>
</article>


</section>

<?php 
include("adminmenu.php");
include("footer.php"); 

?>