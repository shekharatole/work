$(function () {
    $("#from_date").datepicker({
        dateFormat: 'mm/dd/yy',
        changeMonth: true,
        changeYear: true,
        maxDate: "+0D",
        onSelect: function (selected) {
            var dt = new Date(selected);
            $("#to_date").datepicker("option", "minDate", dt);
        }
    });
    $("#to_date").datepicker({
        dateFormat: 'mm/dd/yy',
        changeMonth: true,
        changeYear: true,
        maxDate: "+0D",
        onSelect: function (selected) {
            var dt = new Date(selected);
            $("#from_date").datepicker("option", "maxDate", dt);
        }
    });      
    $('#datepicker-1').datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        maxDate: new Date()
    }).val();
});