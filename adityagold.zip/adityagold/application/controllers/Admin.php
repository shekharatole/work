<?php

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("common_model");
    }

    public function index() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $this->load->view("admin/dashboard");
    }

    public function addnewshop() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        if ($this->input->post('shopname') != '' && $this->input->post('shoptype') != '' && $this->input->post('shopcode') != '') {
            $insertArray = array(
                'shop_name' => $this->input->post('shopname'),
                'shop_type' => $this->input->post('shoptype'),
                'shop_code' => $this->input->post('shopcode'),
                'db_add_date' => date("Y-m-d")
            );
            $insertid = $data = $this->common_model->insertblog("shop_master", $insertArray);
            if ($insertid > 0) {
                $dataArray['status'] = 1;
                $this->session->set_userdata('msg', 'Your Shop Added Successfully !!!');
            }
        }
        $this->load->view("admin/addshop", $dataArray);
    }

    public function shoplist() {

        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        $this->load->view("admin/shoplist", $dataArray);
    }

    public function expenditure() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        $purticular = $this->input->post('purticular');
        $shop_id = $this->input->post('shop_id');
        $amt = $this->input->post('amt');
        $date = $this->input->post('date');

        if ($purticular != '' && $shop_id != '' && $amt != '') {
            $insertArray = array('purticular' => $purticular, 'shop_id' => $shop_id, 'ammount' => $amt, 'db_add_date' => date("Y-m-d", strtotime($date)));
            $insertid = $data = $this->common_model->insertblog("expenditure", $insertArray);
            if ($insertid > 0)
                $dataArray['status'] = 1;
        }

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');

        $this->load->library('pagination');

        $config['base_url'] = base_url();
        $config['total_rows'] = 50;
        $config['per_page'] = 50;

        $this->pagination->initialize($config);

        echo $this->pagination->create_links();
        $this->load->view("admin/expenditure", $dataArray);
    }

    public function expenditurelist($pageoffset = 0) {

        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        
        if ($this->input->post("start") != '' && $this->input->post("end")) {
            $start = date("Y-m-d", strtotime($this->input->post("start")));
            $end = date("Y-m-d", strtotime($this->input->post("end")));
            $shopid = $this->input->post("shopname");
        } else {
            $start = date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"));
            $end = date('Y-m-d');
        }
        
        $expenseCondition = " status='1' AND db_add_date BETWEEN '$start' AND '$end' ";
        $expenseCount = $this->common_model->getPaginationCount("expenditure", $fields = array('id'), $expenseCondition);
        
        /* pagination */
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'admin/expenditurelist';
        $config['total_rows'] = $expenseCount;
        $config['per_page'] = 10;

        $config['cur_tag_open'] = '<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        $pagination = $this->pagination->create_links();
        $data["links"] = explode('&nbsp;',$pagination );
        $dataArray['pagination'] = $data["links"];
        /*End*/   
        
        $dataArray['expense'] = $this->common_model->get_expenditure_report($start, $end, $shopid, $config["per_page"], $pageoffset);
        $totalexpense = $this->common_model->totalexpense($start, $end, $shopid);
        $dataArray['totalexpense'] = $totalexpense;               
        $dataArray['start'] = $start;
        $dataArray['end'] = $end;
        $this->load->view("admin/expenditurelist", $dataArray);
    }

    public function incomelist($pageoffset = 0) {

        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        
        if ($this->input->post("start") != '' && $this->input->post("end")) {
            $start = date("Y-m-d", strtotime($this->input->post("start")));
            $end = date("Y-m-d", strtotime($this->input->post("end")));
            $shopid = $this->input->post("shopname");
        } else {
            $start = date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"));
            $end = date('Y-m-d');
        }
        
        $incomeCondition = " status='1' AND db_add_date BETWEEN '$start' AND '$end' ";
        $totalCount = $this->common_model->getPaginationCount("income", $fields = array('id'), $incomeCondition);
        
        /* pagination */
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'admin/incomelist';
        $config['total_rows'] = $totalCount;
        $config['per_page'] = 10;

        $config['cur_tag_open'] = '<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        $pagination = $this->pagination->create_links();
        $data["links"] = explode('&nbsp;',$pagination );
        $dataArray['pagination'] = $data["links"];
        /*End*/        
        
        $dataArray['income'] = $this->common_model->get_income_report($start, $end, $shopid, $config["per_page"], $pageoffset);
        $totalincome = $this->common_model->totalincome($start, $end, $shopid);
        $dataArray['totalincome'] = $totalincome;        
        $dataArray['start'] = $start;
        $dataArray['end'] = $end;
        $this->load->view("admin/incomelist", $dataArray);
    }

    public function income() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        $incomesource = $this->input->post('incomesource');
        $shop_id = $this->input->post('shop_id');
        $amt = $this->input->post('amt');
        $date = $this->input->post('date');

        if ($incomesource != '' && $shop_id != '' && $amt != '') {
            $insertArray = array('incomesource' => $incomesource, 'shop_id' => $shop_id, 'ammount' => $amt, 'db_add_date' => date("Y-m-d", strtotime($date)));
            $insertid = $data = $this->common_model->insertblog("income", $insertArray);
            if ($insertid > 0)
                $dataArray['status'] = 1;
        }

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');


        $this->load->view("admin/income", $dataArray);
    }

    public function report($pageoffset = 0) {


        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }

        $dataArray = array();

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        if ($this->input->post("start") != '' && $this->input->post("end")) {
            $start = date("Y-m-d", strtotime($this->input->post("start")));
            $end = date("Y-m-d", strtotime($this->input->post("end")));
            $shopid = $this->input->post("shopname");
        } else {
            $start = date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"));
            $end = date('Y-m-d');
        }
        $expenseCondition = " status='1' AND db_add_date BETWEEN '$start' AND '$end' ";
        $expenseCount = $this->common_model->getPaginationCount("expenditure", $fields = array('id'), $expenseCondition);
        
        $incomeCondition = " status='1' AND db_add_date BETWEEN '$start' AND '$end' ";
        $incomeCount = $this->common_model->getPaginationCount("income", $fields = array('id'), $incomeCondition);
        //echo "New ".$expenseCount;
        //die();
        $totalCount = 0;
        if($expenseCount > $incomeCount){
            $totalCount = $expenseCount;
        }else{
            $totalCount = $incomeCount;
        }
        

        /* pagination */
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'admin/report';
        $config['total_rows'] = $totalCount;
        $config['per_page'] = 10;

        $config['cur_tag_open'] = '<a class="current">';
        $config['cur_tag_close'] = '</a>';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';

        $this->pagination->initialize($config);
        $pagination = $this->pagination->create_links();
        $data["links"] = explode('&nbsp;',$pagination );
        //echo $page = $this->uri->segment(3);
        //print_r($data["links"]);
        //die();
        /* End */

        //$dataArray['expense'] = $this->common_model->get_expenditure_report($start, $end, $shopid);
        $dataArray['expense'] = $this->common_model->get_expenditure_report($start, $end, $shopid, $config["per_page"], $pageoffset);
        $dataArray['pagination'] = $data["links"];
        $dataArray['income'] = $this->common_model->get_income_report($start, $end, $shopid, $config["per_page"], $pageoffset);
        $totalexpense = $this->common_model->totalexpense($start, $end, $shopid);
        $totalincome = $this->common_model->totalincome($start, $end, $shopid);
        $dataArray['totalexpense'] = $totalexpense;
        $dataArray['totalincome'] = $totalincome;
        $dataArray['start'] = $start;
        $dataArray['end'] = $end;

        $this->load->view("admin/report", $dataArray);
    }

}

?>