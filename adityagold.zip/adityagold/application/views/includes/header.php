


<head>
    <link href="<?php echo base_url(); ?>media/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="<?php echo base_url(); ?>media/css/style.css" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo base_url(); ?>media/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>media/js/jquery-1.11.1.min.js"></script>
    <script src="<?php echo base_url(); ?>media/js/jquery.validate.js"></script>
    <!--<script src="<?php echo base_url(); ?>media/js/validation.js"></script>-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

