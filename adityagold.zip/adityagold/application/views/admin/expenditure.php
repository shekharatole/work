<!DOCTYPE html>

<style>
    .error{
        color: red;
    }
</style>

<html lang="en">
    <body>

        <div id="wrapper">
            <!----------------------------------------Start Header----------------------------------->
            <?php $this->load->view("admin/header"); ?>
            <!--------------------------------------End Header----------------------------------->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Add Expenditure Detail's</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">



                    <div class="">

                        <?php if ($status == 1) { ?>
                            <div class="alert alert-success">
                                <strong>Success!!</strong> Your Expenditure has added successfully.
                            </div>
                        <?php } ?>

                        <form  id="expense" name="expense" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="form-group">
                                <label for="email">Purticular:</label>
                                <input type="textbox" class="form-control" id="purticular" placeholder="Enter purticular" name="purticular">
                            </div>
                            <div class="form-group">
                                <label for="pwd">Shop Name:</label>
                                <select class="form-control" name="shop_id" id="shop_id">
                                    <option value="default">Select Shop Name</option>
                                    <?php foreach ($shoplist as $val) { ?>
                                        <option value="<?php echo $val['id']; ?>"><?php echo $val['shop_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="pwd">Date:</label>
                                <input type = "text" class="form-control" name="date" id = "datepicker-1" placeholder="Please Select Date">
                            </div>
                            
                            <div class="form-group">
                                <label for="pwd">Ammount:</label>
                                <input type="textbox" class="form-control" id="amt" placeholder="Enter Ammount" name="amt">
                            </div>

                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>


                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-----------------------------------Start Footer-------------------------------->
        <?php $this->load->view("admin/footer"); ?>

        <!-------------------------------------End Footer-------------------------------------->
    </body>

</html>

<script>
    $(document).ready(function () {
        $.validator.addMethod("valueNotEquals", function (value, element, arg) {
            return arg !== value;
        }, "Value must not equal arg.");

        $('#expense').validate({
            rules: {
                purticular: {
                    required: true
                },
                shop_id: {
                    required: true,
                    valueNotEquals: "default"
                },
                amt: {
                    required: true,
                    digits: true
                },
                date:{
                       required: true 
                }
            },
            messages: {
                purticular: {
                    required: "Please Enter purticular Detail."
                },
                shop_id: {
                    required: "Please select shop name.",
                    valueNotEquals: "Please select shop name."
                },
                amt: {
                    required: "Please Enter ammount.",
                    digits: "Please enter only numeric value"
                },
                date:{
                       required: "Please select date" 
                }
            }
        });
    });


    window.setTimeout(function () {
        $(".alert").fadeTo(50, 0).slideUp(50, function () {
            $(this).remove();
        });
    }, 1500);
</script>
<script src="<?php echo base_url(); ?>media/js/datevalidation.js"></script>