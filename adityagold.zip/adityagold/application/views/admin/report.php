<!DOCTYPE html>
<style>
    .tatal{
        float: left;
        font-family: fantasy;
        font-size: 18px;
    }
    .hr{
        margin-top: 20px;
        margin-bottom: 20px;
        border: 12;
        border-color: red;
        border-top: 1px solid #eee;
    }



</style>
<link href="<?php echo base_url(); ?>media/css/pagination.css" rel="stylesheet">
<?php
//echo $pagination;
if ($start != '') {
    $txtFromDate = date('m/d/Y', strtotime($start));
} else {
    $txtFromDate = date('m/d/Y', strtotime(date('m/d/Y') . " -1 month"));
}

if ($end) {
    $txtToDate = date('m/d/Y', strtotime($end));
} else {
    $txtToDate = date('m/d/Y');
}
?>

<html lang="en">
    <body>
        <div id="wrapper">
            <!----------------------------------------Start Header----------------------------------->
            <?php $this->load->view("admin/header"); ?>
            <!--------------------------------------End Header----------------------------------->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Total Expenditure and Income Detail's</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row col-md-12">
                    <form name="search" method="post">
                        <div>
                            <!--<div class="col-md-1 col-sm-2"> <label>StartDate: </label> </div>--> 
                            <div class="col-md-3 col-sm-3">
                                <!--<input type="date" name="start" format="dd-mm-yyyy" style="line-height: 16px;">-->
                                <input type = "text" class="form-control" autocomplete="off" name="start" id = "from_date" value="<?php echo $txtFromDate; ?>" placeholder="Please Select Start Date">
                            </div>
                        </div>
                        <div> 
                            <!--<div class="col-md-2 col-sm-2"> <label> EndDate: </label></div>-->
                            <div class="col-md-3 col-sm-3">
                                <!--<input type="date" name="end"  style="line-height: 16px;">-->
                                <input type = "text" class="form-control" autocomplete="off" name="end" id = "to_date" value="<?php echo $txtToDate; ?>" placeholder="Please Select End Date">
                            </div>
                        </div>
                        <div> 
                            <div class="col-md-2 col-sm-2">  <label> Select Shop:</label></div>

                            <div class="col-md-2 col-sm-2"><select name="shopname" id="shopname">
                                    <option value="">Select Shop</option>
                                    <?php
                                    if (count($shoplist) > 0) {
                                        foreach ($shoplist as $val) {
                                            ?>
                                            <option value="<?php echo $val['id']; ?>"><?php echo $val['shop_name']; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select></div>
                        </div>
                        <div class="col-md-1 col-sm-1">
                            <input type="submit" name="submit" value="submit">
                        </div>
                    </form>
                </div>
                <br><br><br><br>
                <div class="row">

                    <div class="col-lg-6">
                        <h4> <strong> Expenditure Details.</strong></h4>    
                        <table id="expense" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Shop Name</th>
                                    <th>Purticular</th>
                                    <th>Ammount</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                if (count($expense) > 0) {
//                                 echo "<pre>";
//                                 print_r($expense);
//                                    die("exe");
                                    foreach ($expense as $val) {
                                        ?>
                                        <tr>
                                            <td><?php echo date("d-m-Y", strtotime($val['db_add_date'])); ?></td>
                                            <td><?php echo $val['shop_name']; ?></td>
                                            <td><?php echo $val['purticular']; ?></td>
                                            <td  align="right"><?php echo $val['ammount']; ?></td>

                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                            <tfoot>

                            </tfoot>
                        </table>

                    </div>



                    <div class="col-lg-6">
                        <h4> <strong> Income Details.</strong></h4>    
                        <table id="income" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Shop Name</th>
                                    <th>Income Sourse</th>
                                    <th>Ammount</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                if (count($income) > 0) {
                                    foreach ($income as $val) {
                                        ?>
                                        <tr>
                                            <td><?php echo date("d-m-Y", strtotime($val['db_add_date'])); ?></td>
                                            <td><?php echo $val['shop_name']; ?></td>
                                            <td><?php echo $val['incomesource']; ?></td>
                                            <td align="right"><?php echo $val['ammount']; ?></td>

                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                            <tfoot>

                            </tfoot>
                        </table>
                    </div>



                </div>
       
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-4"></div>
                        <div class="col-lg-6">
                            <div id="pagination">
                                <ul class="tsc_pagination">

                                    <!-- Show pagination links -->
                                    <?php
                                    foreach ($pagination as $pagination) {
                                        echo "<li>" . $pagination . "</li>";
                                    }
                                    ?>
                                </ul>
                            </div>
                            <?php //echo $pagination; ?>
                        </div>
                    </div>
                </div>
                
               
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-6 col-sm-6 tatal">Total Expenditure:<?php
                            if ($totalexpense[0]['ammount'] != '')
                                echo($totalexpense[0]['ammount']);
                            else {
                                echo 0;
                            }
                            ?></div>
                        <div class="col-md-6 col-sm-6 tatal">Total Income:<?php
                            if ($totalincome[0]['ammount'])
                                echo($totalincome[0]['ammount']);
                            else {
                                echo 0;
                            }
                            ?></div>

                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12"> <hr class="hr"></div>
                <div>
                    <?php if ($totalincome[0]['ammount'] > $totalexpense[0]['ammount']) { ?>

                        <div class="col-md-6 col-sm-6 col-xs-6" style="font-family: fantasy;font-size: 18px;">Total Profit:<?php echo $totalincome[0]['ammount'] - $totalexpense[0]['ammount']; ?> </div>   
                        <div class="col-md-6 col-sm-6 col-xs-6" style="font-family: fantasy;font-size: 18px;">Total Loss:0</div>  
                    <?php } else { ?>
                        <div class="col-md-6 col-sm-6 col-xs-6" style="font-family: fantasy;font-size: 18px;">Total Loss:<?php echo $totalexpense[0]['ammount'] - $totalincome[0]['ammount']; ?> </div>    
                        <div class="col-md-6 col-sm-6 col-xs-6" style="font-family: fantasy;font-size: 18px;">Total Profit:0</div>              
                    <?php } ?>

                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-----------------------------------Start Footer-------------------------------->
        <?php $this->load->view("admin/footer"); ?>

        <!-------------------------------------End Footer-------------------------------------->
    </body>

</html>

<script>
    $(document).ready(function () {
//        $('#expense').DataTable();
//        $('#income').DataTable();
    });

    $(document).ready(function () {
        $('#addshop').validate({
            rules: {
                shopcode: {
                    required: true
                },
                shopname: {
                    required: true
                },
                shoptype: {
                    required: true
                }
            },
            messages: {
                shopcode: {
                    required: "Please Enter shopcode name."
                },
                shopname: {
                    required: "Please Enter shop name."
                },
                shoptype: {
                    required: "Please Enter shop Type."
                }
            }
        });
    });

// $(function () {
////            $( "#datepicker-1" ).datepicker();
//        $('#datepicker-1').datepicker({dateFormat: 'dd-mm-yy'}).val();
//        $('#datepicker-2').datepicker({dateFormat: 'dd-mm-yy'}).val();
//    });


</script>
<script src="<?php echo base_url(); ?>media/js/datevalidation.js"></script>
<!--<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>-->