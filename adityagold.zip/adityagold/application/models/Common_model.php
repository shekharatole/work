<?php

class Common_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insertblog($tablename, $data) {

        $this->db->insert($tablename, $data);
        return $this->db->insert_id();
    }

    public function updaterow($tablename, $condition, $updatedata) {
        if ($condition != '') {
            foreach ($condition as $field => $value) {
                $this->db->where($field, $value);
            }
        }
        $this->db->update($tablename, $updatedata);
    }

    public function deleterow($tablename, $condition) {
        if ($condition != '') {
            foreach ($condition as $field => $value) {
                $this->db->where($field, $value);
            }
        }
        $this->db->delete($tablename);
    }

    public function getnumrows($tablename) {
        $this->db->select('*');
        $this->db->from($tablename);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function getblogs() {
        $this->db->select('blog.id,blog.title,blog.des,categories.name');
        $this->db->from('blogcategory');
        $this->db->join('blog', 'blogcategory.blogid=blog.id');
        $this->db->join('categories', 'blogcategory.categoryid=categories.id');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function totalexpense($start, $end, $shop_id = "") {
        $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND expenditure.shop_id=$shop_id";
        }
        $query = $this->db->query("SELECT SUM(ammount) as ammount FROM `expenditure` WHERE status ='1' AND db_add_date BETWEEN '$start' AND '$end'" . $shopCondition);
        return $query->result_array();
    }

    public function totalincome($start, $end, $shop_id = "") {
        $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND income.shop_id=$shop_id";
        }
        $query = $this->db->query("SELECT SUM(ammount) as ammount FROM `income` WHERE status ='1' AND db_add_date BETWEEN '$start' AND '$end'" . $shopCondition);
        return $query->result_array();
    }

    function get_income_report($startdate, $enddate, $shop_id = "",$limit = '',$offset='') {
        $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND income.shop_id=$shop_id";
        }
        $condition = "  income.status='1' AND income.db_add_date BETWEEN '$startdate' AND '$enddate' " . $shopCondition;
        $this->db->select('income.id,income.shop_id,income.incomesource,income.ammount,income.db_add_date,shop_master.shop_name');
        $this->db->from('income');
        $this->db->join('shop_master', 'shop_master.id=income.shop_id');
        $this->db->where($condition);
        $this->db->limit($limit,$offset);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getTotalIncome($startdate, $enddate, $shop_id = "") {
        $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND income.shop_id=$shop_id";
        }
        $condition = "  income.status='1' AND income.db_add_date BETWEEN '$startdate' AND '$enddate' " . $shopCondition;
        $this->db->select('income.id,income.shop_id,income.incomesource,income.ammount,income.db_add_date,shop_master.shop_name');
        $this->db->from('income');
        $this->db->join('shop_master', 'shop_master.id=income.shop_id');
        $this->db->where($condition);
        $query = $this->db->get();
        return $query->result_array();
    }


    function get_expenditure_report($startdate, $enddate, $shop_id = "",$limit,$offset) {
        $shopCondition = "";
        if ($shop_id != '') {
            $shopCondition = " AND expenditure.shop_id=$shop_id";
        }
        //$condition = " expenditure.id = ".$id;
        $condition .= " expenditure.status='1' AND expenditure.db_add_date BETWEEN '$startdate' AND '$enddate' " . $shopCondition;
        
        $this->db->select('expenditure.id,expenditure.shop_id,expenditure.purticular,expenditure.ammount,expenditure.db_add_date,shop_master.shop_name');
        $this->db->from('expenditure');
        $this->db->join('shop_master', 'shop_master.id=expenditure.shop_id');
        $this->db->where($condition);
        $this->db->limit($limit,$offset);
        //die($condition);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getrecoreds($tablename, $fields, $condition, $limit = '', $offset = '', $order_by = 'DESC') {

        if (count($fields) > 0) {
            if ($fields != '')
                $field = implode(",", $fields);
        }else {
            $field = '*';
        }

        if (count($condition)) {
            foreach ($condition as $fieldname => $fieldval) {
                $this->db->where($fieldname, $fieldval);
            }
        } elseif ($condition != '') {
            $this->db->where($condition);
        }

        $this->db->select($field);
        $this->db->from($tablename);
        $this->db->limit($limit);
        $this->db->order_by($order_by);
        $this->db->offset($offset);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function getPaginationCount($table, $fields, $condition){
        if (count($fields) > 0) {
            if ($fields != '')
                $field = implode(",", $fields);
        }else {
            $field = '*';
        }
        $this->db->select($field);
        $this->db->from($table);
        $this->db->where($condition);
        $query = $this->db->get();
        return count($query->result_array());
    }

}

?>
